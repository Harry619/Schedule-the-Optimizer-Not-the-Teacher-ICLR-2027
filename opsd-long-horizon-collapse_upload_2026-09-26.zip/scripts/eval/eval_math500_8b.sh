#!/bin/bash
# MATH500 eval for a 4B LoRA checkpoint (4B base model + checkpoint_dir).
# Usage: bash eval_math500_4b.sh <checkpoint_dir> <tag> <gpu_ids>
set -u
CKPT=$1
TAG=$2
GPUS=$3
export PATH=${OPSD_ROOT:-/root/autodl-tmp}/envs/opsd/bin:$PATH
export HF_HOME=${OPSD_ROOT:-/root/autodl-tmp}/huggingface
export HF_ENDPOINT=https://hf-mirror.com
export HF_HUB_DISABLE_XET=1
export VLLM_LOGGING_LEVEL=WARNING
cd ${OPSD_ROOT:-/root/autodl-tmp}/OPSD/eval

OUTDIR=${OPSD_ROOT:-/root/autodl-tmp}/eval_results_daw
if [ -f "$OUTDIR/${TAG}_math500.json" ]; then
    echo "=== [${TAG}] math500 exists, skip ==="
    exit 0
fi
echo "=== [${TAG}] math500 start $(date '+%H:%M:%S') ==="
NCCL_P2P_DISABLE=1 CUDA_VISIBLE_DEVICES=${GPUS} python evaluate_math.py \
    --base_model ${OPSD_ROOT:-/root/autodl-tmp}/models/Qwen3-8B \
    --dataset math500 \
    --val_n 4 \
    --temperature 1.0 \
    --tensor_parallel_size 4 \
    --checkpoint_dir "$CKPT" \
    --output_file "$OUTDIR/${TAG}_math500.json"
echo "=== [${TAG}] math500 done $(date '+%H:%M:%S') ==="
