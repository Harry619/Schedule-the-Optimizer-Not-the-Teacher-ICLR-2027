#!/bin/bash
# Evaluate one checkpoint on AIME24/AIME25/HMMT25 with the exact paper protocol:
# thinking mode, temperature 1.0, val_n 12 (Avg@12), max_new_tokens 38912 (default).
# Usage: bash eval_ckpt.sh <checkpoint_dir> <tag> <gpu_ids e.g. 0,1,2,3>
set -e
CKPT=$1
TAG=$2
GPUS=${3:-0,1,2,3}
export PATH=${OPSD_ROOT:-/root/autodl-tmp}/envs/opsd/bin:$PATH
export HF_HOME=${OPSD_ROOT:-/root/autodl-tmp}/huggingface
export HF_ENDPOINT=https://hf-mirror.com
export HF_HUB_DISABLE_XET=1
export VLLM_LOGGING_LEVEL=WARNING
cd ${OPSD_ROOT:-/root/autodl-tmp}/OPSD/eval

BASE_MODEL=${OPSD_ROOT:-/root/autodl-tmp}/models/Qwen3-1.7B
OUTDIR=${OPSD_ROOT:-/root/autodl-tmp}/eval_results_daw
mkdir -p "$OUTDIR"

for DS in aime24 aime25 hmmt25; do
    echo "=== [${TAG}] ${DS} start $(date '+%H:%M:%S') ==="
    NCCL_P2P_DISABLE=1 CUDA_VISIBLE_DEVICES=${GPUS} python evaluate_math.py \
        --base_model "$BASE_MODEL" \
        --dataset "$DS" \
        --val_n 12 \
        --temperature 1.0 \
        --tensor_parallel_size 4 \
        --checkpoint_dir "$CKPT" \
        --output_file "$OUTDIR/${TAG}_${DS}.json"
    echo "=== [${TAG}] ${DS} done $(date '+%H:%M:%S') ==="
done
echo "ALL_DONE ${TAG}"
