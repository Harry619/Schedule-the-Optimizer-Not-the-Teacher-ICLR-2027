#!/bin/bash
# Evaluate the Qwen3-4B BASE model (no LoRA) on AIME24/AIME25/HMMT25,
# exact paper protocol (thinking mode, temp 1.0, val_n 12, max 38912).
# Usage: bash eval_base_4b.sh <tag> <gpu_ids>
set -u
TAG=${1:-4b_base}
GPUS=${2:-0,1,2,3}
export PATH=${OPSD_ROOT:-/root/autodl-tmp}/envs/opsd/bin:$PATH
export HF_HOME=${OPSD_ROOT:-/root/autodl-tmp}/huggingface
export HF_ENDPOINT=https://hf-mirror.com
export HF_HUB_DISABLE_XET=1
export VLLM_LOGGING_LEVEL=WARNING
cd ${OPSD_ROOT:-/root/autodl-tmp}/OPSD/eval

BASE_MODEL=${OPSD_ROOT:-/root/autodl-tmp}/models/Qwen3-4B
OUTDIR=${OPSD_ROOT:-/root/autodl-tmp}/eval_results_daw
mkdir -p "$OUTDIR"

for DS in aime24 aime25 hmmt25; do
    if [ -f "$OUTDIR/${TAG}_${DS}.json" ]; then
        echo "=== [${TAG}] ${DS} exists, skip ==="
        continue
    fi
    echo "=== [${TAG}] ${DS} start $(date '+%H:%M:%S') ==="
    NCCL_P2P_DISABLE=1 CUDA_VISIBLE_DEVICES=${GPUS} python evaluate_math.py \
        --base_model "$BASE_MODEL" \
        --dataset "$DS" \
        --val_n 12 \
        --temperature 1.0 \
        --tensor_parallel_size 4 \
        --output_file "$OUTDIR/${TAG}_${DS}.json"
    echo "=== [${TAG}] ${DS} done $(date '+%H:%M:%S') ==="
done
echo "ALL_DONE ${TAG}"
