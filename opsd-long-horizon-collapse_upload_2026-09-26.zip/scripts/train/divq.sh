#!/bin/bash
# Divergence-family probe queue (user-approved 2026-09-16): JSD (beta=0.5) and
# reverse KL (beta=1), each 300 steps + eval ckpt-300/200/100 on GPUs 0-3.
# Sequential; this wrapper's own cmdline contains no RUNCFG string, so the
# per-unit pkill cleanup inside long_run_300_beta.sh cannot kill this chain.
set -u
echo "=== divq start $(date '+%F %H:%M:%S') ==="

# Run 1: generalized JSD, beta = 0.5
bash ${OPSD_ROOT:-/root/autodl-tmp}/OPSD/scripts/long_run_300_beta.sh jsd05 0,1,2,3 none 0.5
echo "=== [divq] jsd05 unit returned (rc=$?) $(date '+%H:%M:%S') ==="
if [ ! -f ${OPSD_ROOT:-/root/autodl-tmp}/eval_results_daw/jsd05_100_hmmt25.json ]; then
    bash ${OPSD_ROOT:-/root/autodl-tmp}/OPSD/eval/eval_ckpt.sh \
        ${OPSD_ROOT:-/root/autodl-tmp}/opsd_daw_outputs/qwen31b_jsd05_gen1024_fixteacher_temp11_forwardbeta05_clip005/checkpoint-100 \
        jsd05_100 0,1,2,3
fi
echo "=== [divq] jsd05 COMPLETE (300/200/100) $(date '+%H:%M:%S') ==="

# Run 2: reverse KL, beta = 1
bash ${OPSD_ROOT:-/root/autodl-tmp}/OPSD/scripts/long_run_300_beta.sh rkl1 0,1,2,3 none 1
echo "=== [divq] rkl1 unit returned (rc=$?) $(date '+%H:%M:%S') ==="
if [ ! -f ${OPSD_ROOT:-/root/autodl-tmp}/eval_results_daw/rkl1_100_hmmt25.json ]; then
    bash ${OPSD_ROOT:-/root/autodl-tmp}/OPSD/eval/eval_ckpt.sh \
        ${OPSD_ROOT:-/root/autodl-tmp}/opsd_daw_outputs/qwen31b_rkl1_gen1024_fixteacher_temp11_forwardbeta1_clip005/checkpoint-100 \
        rkl1_100 0,1,2,3
fi

echo "=== divq ALL_DONE $(date '+%F %H:%M:%S') ==="
