#!/bin/bash
# OPSD 主实验复现脚本 —— 基于官方 scripts/run_opsd_1b.sh
# 适配说明（除以下两项外，所有超参数与官方完全一致）：
#   1) GPU 4卡 -> 8卡：num_processes 4->8，gradient_accumulation_steps 2->1，
#      保持全局 batch = per_device(4) x accum(1) x nproc(8) = 32 与官方一致
#   2) 路径适配：模型与输出目录改为本机路径
set -e
cd ${OPSD_ROOT:-/root/autodl-tmp}/OPSD

accelerate launch \
    --config_file accelerate_a800x8.yaml \
    --num_processes 8 \
    --gradient_accumulation_steps 1 \
    --main_process_port 12949 \
    opsd_train.py \
    --model_name_or_path ${OPSD_ROOT:-/root/autodl-tmp}/models/Qwen3-1.7B \
    --learning_rate 5e-6 \
    --max_grad_norm 0.1 \
    --per_device_train_batch_size 4 \
    --gradient_checkpointing \
    --gradient_accumulation_steps 1 \
    --output_dir ${OPSD_ROOT:-/root/autodl-tmp}/opsd_outputs/ \
    --run_config qwen31b_gen1024_fixteacher_temp11_forwardbeta0_clip005 \
    --num_train_epochs 30 \
    --max_completion_length 1024 \
    --save_steps 25 \
    --logging_steps 2 \
    --attn_implementation flash_attention_2 \
    --torch_dtype bfloat16 \
    --max_length 20000 \
    --beta 0 \
    --use_vllm \
    --vllm_mode colocate \
    --vllm_gpu_memory_utilization 0.6 \
    --vllm_tensor_parallel_size 1 \
    --use_peft \
    --lora_r 64 \
    --lora_alpha 128 \
    --lora_target_modules q_proj k_proj v_proj o_proj gate_proj up_proj down_proj \
    --temperature 1.1 \
    --top_p 0.95 \
    --top_k 20 \
    --lmbda 1 \
    --fixed_teacher \
    --jsd_token_clip 0.05 \
    --wandb_project OPSD
