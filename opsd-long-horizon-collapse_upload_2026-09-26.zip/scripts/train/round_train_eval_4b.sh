#!/bin/bash
# 4B variant of the atomic experiment unit (Qwen3-4B, thinking mode).
# Same hyperparameters as official run_opsd_4b.sh (global batch 32, lr 5e-6,
# clip 0.05, temp 1.1, completion 1024), adapted to 4 GPUs: per_device 8 x nproc 4.
# vllm_gpu_memory_utilization=0.4 to leave headroom for the 4B training side.
# Usage: bash round_train_eval_4b.sh <tag> <gpus> <wait_json|none> [extra args...]
set -u
TAG=$1
GPUS=$2
WAITJSON=$3
shift 3
export PATH=${OPSD_ROOT:-/root/autodl-tmp}/envs/opsd/bin:$PATH
export HF_HOME=${OPSD_ROOT:-/root/autodl-tmp}/huggingface
export HF_ENDPOINT=https://hf-mirror.com
export HF_HUB_DISABLE_XET=1
export WANDB_MODE=offline
export TOKENIZERS_PARALLELISM=false
export CUDA_VISIBLE_DEVICES=${GPUS}
cd ${OPSD_ROOT:-/root/autodl-tmp}/OPSD

# Wait for the 4B model download to finish first
while [ ! -f ${OPSD_ROOT:-/root/autodl-tmp}/model4b.done ]; do sleep 60; done

# Idempotency: skip if eval results exist
if [ -f "${OPSD_ROOT:-/root/autodl-tmp}/eval_results_daw/${TAG}_100_hmmt25.json" ]; then
    echo "=== [${TAG}] eval results already exist, SKIP $(date '+%H:%M:%S') ==="
    exit 0
fi

# Bounded wait for the previous stage marker; proceed early only if own GPU
# group has been free for 8 consecutive minutes (previous stage dead/done)
if [ "${WAITJSON}" != "none" ]; then
    OWNGPU=${GPUS%%,*}
    FREECNT=0
    echo "=== [${TAG}] waiting for ${WAITJSON} $(date '+%H:%M:%S') ==="
    while [ ! -f "${OPSD_ROOT:-/root/autodl-tmp}/eval_results_daw/${WAITJSON}" ]; do
        sleep 60
        MEM=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i ${OWNGPU} 2>/dev/null || echo 0)
        if [ "${MEM}" -lt 1000 ]; then FREECNT=$((FREECNT+1)); else FREECNT=0; fi
        if [ ${FREECNT} -ge 8 ]; then
            echo "=== [${TAG}] own GPU group free 8min, proceeding $(date '+%H:%M:%S') ==="
            break
        fi
    done
fi

RUNCFG="qwen34b_${TAG}_gen1024_fixteacher_temp11_forwardbeta0_clip005"
OUT="${OPSD_ROOT:-/root/autodl-tmp}/opsd_daw_outputs/${RUNCFG}"
PORT=12989
case "${GPUS}" in 4*) PORT=13019 ;; esac

if [ ! -f "${OUT}/checkpoint-100/trainer_state.json" ]; then
    rm -rf "${OUT}"
    echo "=== [${TAG}] 4B train start $(date '+%H:%M:%S') gpus=${GPUS} ==="
    nohup accelerate launch \
        --config_file accelerate_a800x8.yaml \
        --num_processes 4 \
        --gradient_accumulation_steps 1 \
        --main_process_port ${PORT} \
        opsd_train.py \
        --model_name_or_path ${OPSD_ROOT:-/root/autodl-tmp}/models/Qwen3-4B \
        --learning_rate 5e-6 \
        --max_grad_norm 0.1 \
        --per_device_train_batch_size 8 \
        --gradient_checkpointing \
        --gradient_accumulation_steps 1 \
        --output_dir ${OPSD_ROOT:-/root/autodl-tmp}/opsd_daw_outputs/ \
        --run_config "${RUNCFG}" \
        --num_train_epochs 30 \
        --max_completion_length 1024 \
        --save_steps 25 \
        --logging_steps 2 \
        --attn_implementation flash_attention_2 \
        --torch_dtype bfloat16 \
        --max_length 20000 \
        --beta 0 \
        --use_vllm \
        --vllm_mode colocate \
        --vllm_gpu_memory_utilization 0.4 \
        --vllm_tensor_parallel_size 1 \
        --use_peft \
        --lora_r 64 \
        --lora_alpha 128 \
        --lora_target_modules q_proj k_proj v_proj o_proj gate_proj up_proj down_proj \
        --temperature 1.1 \
        --top_p 0.95 \
        --top_k 20 \
        --lmbda 1 \
        --jsd_token_clip 0.05 \
        --fixed_teacher \
        "$@" \
        --wandb_project OPSD \
        > "${OPSD_ROOT:-/root/autodl-tmp}/opsd_4b_${TAG}.log" 2>&1 &

    while [ ! -f "${OUT}/checkpoint-100/trainer_state.json" ]; do
        sleep 30
        if ! pgrep -f "${RUNCFG}" > /dev/null; then
            echo "=== [${TAG}] TRAINING_CRASHED $(date '+%H:%M:%S') ==="
            exit 1
        fi
    done
    sleep 30
    pkill -TERM -f "${RUNCFG}" 2>/dev/null; sleep 5
    pkill -TERM -f "${RUNCFG}" 2>/dev/null; sleep 15
    pkill -KILL -f "${RUNCFG}" 2>/dev/null; sleep 10
    echo "=== [${TAG}] stopped after checkpoint-100 $(date '+%H:%M:%S'), start eval ==="
else
    echo "=== [${TAG}] checkpoint-100 exists, skip training $(date '+%H:%M:%S') ==="
fi

bash ${OPSD_ROOT:-/root/autodl-tmp}/OPSD/eval/eval_ckpt_4b.sh "${OUT}/checkpoint-100" "${TAG}_100" "${GPUS}"
echo "=== [${TAG}] unit done $(date '+%H:%M:%S') ==="
