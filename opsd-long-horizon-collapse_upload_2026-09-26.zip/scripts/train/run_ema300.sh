#!/bin/bash
# EMA-300 unit: constant-LR 30-epoch skeleton (verbatim from run_150.sh / long_run_300.sh
# except the teacher flags), watchdog-stopped at checkpoint-300, evals ckpt-300 only
# (spectrum terminal is what matters). EMA replaces the frozen teacher:
#   --use_ema_teacher --ema_decay <decay>   (mutually exclusive with --fixed_teacher)
# Usage: bash run_ema300.sh <tag> <decay> <gpus> [extra trainer args...]
set -u
TAG=$1
DECAY=$2
GPUS=$3
shift 3
export PATH=${OPSD_ROOT:-/root/autodl-tmp}/envs/opsd/bin:$PATH
export HF_HOME=${OPSD_ROOT:-/root/autodl-tmp}/huggingface
export HF_ENDPOINT=https://hf-mirror.com
export HF_HUB_DISABLE_XET=1
export WANDB_MODE=offline
export TOKENIZERS_PARALLELISM=false
export CUDA_VISIBLE_DEVICES=${GPUS}
cd ${OPSD_ROOT:-/root/autodl-tmp}/OPSD

RUNCFG="qwen31b_${TAG}_gen1024_emadecay${DECAY}_temp11_forwardbeta0_clip005"
OUT="${OPSD_ROOT:-/root/autodl-tmp}/opsd_daw_outputs/${RUNCFG}"
PORT=12989
case "${GPUS}" in 4*) PORT=13019 ;; esac

if [ ! -f "${OUT}/checkpoint-300/trainer_state.json" ]; then
    rm -rf "${OUT}"
    echo "=== [${TAG}] ema-300 train start $(date '+%F %H:%M:%S') gpus=${GPUS} decay=${DECAY} ==="
    nohup accelerate launch \
        --config_file accelerate_a800x8.yaml \
        --num_processes 4 \
        --gradient_accumulation_steps 1 \
        --main_process_port ${PORT} \
        opsd_train.py \
        --model_name_or_path ${OPSD_ROOT:-/root/autodl-tmp}/models/Qwen3-1.7B \
        --learning_rate 5e-6 \
        --max_grad_norm 0.1 \
        --per_device_train_batch_size 8 \
        --gradient_checkpointing \
        --gradient_accumulation_steps 1 \
        --output_dir ${OPSD_ROOT:-/root/autodl-tmp}/opsd_daw_outputs/ \
        --run_config "${RUNCFG}" \
        --num_train_epochs 30 \
        --max_completion_length 1024 \
        --save_steps 50 \
        --logging_steps 2 \
        --attn_implementation flash_attention_2 \
        --torch_dtype bfloat16 \
        --max_length 20000 \
        --beta 0 \
        --use_vllm \
        --vllm_mode colocate \
        --vllm_gpu_memory_utilization 0.5 \
        --vllm_tensor_parallel_size 1 \
        --use_peft \
        --lora_r 64 \
        --lora_alpha 128 \
        --lora_target_modules q_proj k_proj v_proj o_proj gate_proj up_proj down_proj \
        --temperature 1.1 \
        --top_p 0.95 \
        --top_k 20 \
        --lmbda 1 \
        --jsd_token_clip 0.05 \
        --use_ema_teacher \
        --ema_decay ${DECAY} \
        "$@" \
        --wandb_project OPSD \
        > "${OPSD_ROOT:-/root/autodl-tmp}/opsd_${TAG}.log" 2>&1 &

    while [ ! -f "${OUT}/checkpoint-300/trainer_state.json" ]; do
        sleep 30
        if ! pgrep -f "${RUNCFG}" > /dev/null; then
            echo "=== [${TAG}] TRAINING_CRASHED $(date '+%F %H:%M:%S') ==="
            exit 1
        fi
    done
    sleep 30
    pkill -TERM -f "${RUNCFG}" 2>/dev/null; sleep 5
    pkill -TERM -f "${RUNCFG}" 2>/dev/null; sleep 15
    pkill -KILL -f "${RUNCFG}" 2>/dev/null; sleep 10
    echo "=== [${TAG}] stopped after checkpoint-300 $(date '+%F %H:%M:%S') ==="
else
    echo "=== [${TAG}] checkpoint-300 exists, skip training $(date '+%F %H:%M:%S') ==="
fi

if [ ! -f "${OPSD_ROOT:-/root/autodl-tmp}/eval_results_daw/${TAG}_hmmt25.json" ]; then
    bash ${OPSD_ROOT:-/root/autodl-tmp}/OPSD/eval/eval_ckpt.sh "${OUT}/checkpoint-300" "${TAG}" "${GPUS}"
fi
echo "=== EMA300_UNIT_DONE tag=${TAG} ==="
