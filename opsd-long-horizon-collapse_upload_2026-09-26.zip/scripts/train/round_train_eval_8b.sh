#!/bin/bash
# Atomic experiment unit: train 100 steps (auto-stop) + eval checkpoint-100.
# Usage: bash round_train_eval.sh <tag> <gpus> <wait_json|none> [extra trainer args...]
# Example: bash round_train_eval.sh bandpass_s1 4,5,6,7 baseline25_hmmt25.json --seed 1 --difficulty_aware bandpass
set -u
TAG=$1
GPUS=$2
WAITJSON=$3
shift 3
export PATH=${OPSD_ROOT:-/root/autodl-tmp}/envs/opsd/bin:$PATH
export HF_HOME=${OPSD_ROOT:-/root/autodl-tmp}/huggingface
export HF_ENDPOINT=https://hf-mirror.com
export HF_HUB_DISABLE_XET=1
export WANDB_MODE=offline
export TOKENIZERS_PARALLELISM=false
export CUDA_VISIBLE_DEVICES=${GPUS}
cd ${OPSD_ROOT:-/root/autodl-tmp}/OPSD
while [ ! -f ${OPSD_ROOT:-/root/autodl-tmp}/model8b.done ]; do sleep 60; done

# Idempotency: skip this unit entirely if its eval results already exist
if [ -f "${OPSD_ROOT:-/root/autodl-tmp}/eval_results_daw/${TAG}_100_hmmt25.json" ]; then
    echo "=== [${TAG}] eval results already exist, SKIP $(date '+%H:%M:%S') ==="
    exit 0
fi

# Wait for the previous stage's completion marker.
# Exit conditions: (a) marker file exists; (b) previous stage DIED (no eval/train
# process left -> GPUs are free, proceed immediately); (c) hard cap 12h.
if [ "${WAITJSON}" != "none" ]; then
    echo "=== [${TAG}] waiting for ${WAITJSON} $(date '+%H:%M:%S') ==="
    WAITED=0
    FREECNT=0
    OWNGPU=${GPUS%%,*}   # first GPU index of this group
    while [ ! -f "${OPSD_ROOT:-/root/autodl-tmp}/eval_results_daw/${WAITJSON}" ]; do
        sleep 60
        WAITED=$((WAITED+1))
        # Previous stage is considered GONE only when this group's own GPU stays
        # free for 3 consecutive minutes (avoids false positives from the brief
        # memory dip between an eval's dataset transitions)
        MEM=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i ${OWNGPU} 2>/dev/null || echo 0)
        if [ "${MEM}" -lt 1000 ]; then
            FREECNT=$((FREECNT+1))
        else
            FREECNT=0
        fi
        if [ ${FREECNT} -ge 3 ]; then
            echo "=== [${TAG}] own GPU group free for 3min, proceeding $(date '+%H:%M:%S') ==="
            break
        fi
        if [ ${WAITED} -ge 720 ]; then
            echo "=== [${TAG}] wait HARD TIMEOUT (12h), proceeding anyway $(date '+%H:%M:%S') ==="
            break
        fi
    done
fi

RUNCFG="qwen38b_${TAG}_gen1024_fixteacher_temp11_forwardbeta0_clip005"
OUT="${OPSD_ROOT:-/root/autodl-tmp}/opsd_daw_outputs/${RUNCFG}"

# Idempotency: if checkpoint-100 already exists, skip training and go straight to eval
if [ -f "${OUT}/checkpoint-100/trainer_state.json" ]; then
    echo "=== [${TAG}] checkpoint-100 exists, skip training, eval only $(date '+%H:%M:%S') ==="
    bash ${OPSD_ROOT:-/root/autodl-tmp}/OPSD/eval/eval_ckpt.sh "${OUT}/checkpoint-100" "${TAG}_100" "${GPUS}"
    echo "=== [${TAG}] unit done $(date '+%H:%M:%S') ==="
    exit 0
fi
rm -rf "${OUT}"
VLLM_UTIL=0.5
case "${TAG}" in *hybrid*) VLLM_UTIL=0.4 ;; esac
PORT=12979
case "${GPUS}" in 4*) PORT=13009 ;; esac

echo "=== [${TAG}] train start $(date '+%H:%M:%S') gpus=${GPUS} ==="
nohup accelerate launch \
    --config_file accelerate_a800x8.yaml \
    --num_processes 4 \
    --gradient_accumulation_steps 2 \
    --main_process_port ${PORT} \
    opsd_train.py \
    --model_name_or_path ${OPSD_ROOT:-/root/autodl-tmp}/models/Qwen3-8B \
    --learning_rate 5e-6 \
    --max_grad_norm 0.1 \
    --per_device_train_batch_size 4 \
    --gradient_checkpointing \
    --gradient_accumulation_steps 2 \
    --output_dir ${OPSD_ROOT:-/root/autodl-tmp}/opsd_daw_outputs/ \
    --run_config "${RUNCFG}" \
    --num_train_epochs 30 \
    --max_completion_length 1024 \
    --save_steps 25 \
    --logging_steps 2 \
    --attn_implementation flash_attention_2 \
    --torch_dtype bfloat16 \
    --max_length 20000 \
    --beta 0 \
    --use_vllm \
    --vllm_mode colocate \
    --vllm_gpu_memory_utilization 0.35 \
    --vllm_tensor_parallel_size 1 \
    --use_peft \
    --lora_r 64 \
    --lora_alpha 128 \
    --lora_target_modules q_proj k_proj v_proj o_proj gate_proj up_proj down_proj \
    --temperature 1.1 \
    --top_p 0.95 \
    --top_k 20 \
    --lmbda 1 \
    --jsd_token_clip 0.05 \
    --fixed_teacher \
    "$@" \
    --wandb_project OPSD \
    > "${OPSD_ROOT:-/root/autodl-tmp}/opsd_${TAG}.log" 2>&1 &

# Wait for checkpoint-100 with crash guard
while [ ! -f "${OUT}/checkpoint-100/trainer_state.json" ]; do
    sleep 30
    if ! pgrep -f "${RUNCFG}" > /dev/null; then
        echo "=== [${TAG}] TRAINING_CRASHED $(date '+%H:%M:%S') ==="
        return 1 2>/dev/null || exit 1
    fi
done
sleep 30
pkill -TERM -f "${RUNCFG}" 2>/dev/null; sleep 5
pkill -TERM -f "${RUNCFG}" 2>/dev/null; sleep 15
pkill -KILL -f "${RUNCFG}" 2>/dev/null; sleep 10
echo "=== [${TAG}] stopped after checkpoint-100 $(date '+%H:%M:%S'), start eval ==="
bash ${OPSD_ROOT:-/root/autodl-tmp}/OPSD/eval/eval_ckpt.sh "${OUT}/checkpoint-100" "${TAG}_100" "${GPUS}"
echo "=== [${TAG}] unit done $(date '+%H:%M:%S') ==="
