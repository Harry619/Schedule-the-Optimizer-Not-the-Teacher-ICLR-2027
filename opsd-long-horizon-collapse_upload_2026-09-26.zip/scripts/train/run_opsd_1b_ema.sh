#!/bin/bash
# OPSD + EMA teacher ablation (proposal C): identical hyperparameters to the
# official run_opsd_1b.sh, except --fixed_teacher is replaced by
# --use_ema_teacher (teacher = EMA of student weights, decay 0.999).
# Keeps the official 30-epoch cosine LR schedule; stop after checkpoint-100.
set -e
export PATH=${OPSD_ROOT:-/root/autodl-tmp}/envs/opsd/bin:$PATH
export HF_HOME=${OPSD_ROOT:-/root/autodl-tmp}/huggingface
export HF_ENDPOINT=https://hf-mirror.com
export HF_HUB_DISABLE_XET=1
export WANDB_MODE=offline
export TOKENIZERS_PARALLELISM=false
cd ${OPSD_ROOT:-/root/autodl-tmp}/OPSD

accelerate launch \
    --config_file accelerate_a800x8.yaml \
    --num_processes 8 \
    --gradient_accumulation_steps 1 \
    --main_process_port 12969 \
    opsd_train.py \
    --model_name_or_path ${OPSD_ROOT:-/root/autodl-tmp}/models/Qwen3-1.7B \
    --learning_rate 5e-6 \
    --max_grad_norm 0.1 \
    --per_device_train_batch_size 4 \
    --gradient_checkpointing \
    --gradient_accumulation_steps 1 \
    --output_dir ${OPSD_ROOT:-/root/autodl-tmp}/opsd_daw_outputs/ \
    --run_config qwen31b_emateacher_gen1024_temp11_forwardbeta0_clip005 \
    --num_train_epochs 30 \
    --max_completion_length 1024 \
    --save_steps 25 \
    --logging_steps 2 \
    --attn_implementation flash_attention_2 \
    --torch_dtype bfloat16 \
    --max_length 20000 \
    --beta 0 \
    --use_vllm \
    --vllm_mode colocate \
    --vllm_gpu_memory_utilization 0.6 \
    --vllm_tensor_parallel_size 1 \
    --use_peft \
    --lora_r 64 \
    --lora_alpha 128 \
    --lora_target_modules q_proj k_proj v_proj o_proj gate_proj up_proj down_proj \
    --temperature 1.1 \
    --top_p 0.95 \
    --top_k 20 \
    --lmbda 1 \
    --use_ema_teacher \
    --ema_decay 0.999 \
    --jsd_token_clip 0.05 \
    --wandb_project OPSD
