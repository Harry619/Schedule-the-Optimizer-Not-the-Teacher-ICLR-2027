#!/bin/bash
# Long-budget (300-step) experiment unit, beta-family variant: identical to
# long_run_300.sh except (i) the generalized-JSD beta is a parameter and
# (ii) the run dir records the actual beta (forwardbeta05 / forwardbeta1)
# instead of the hardcoded forwardbeta0.
# Usage: bash long_run_300_beta.sh <tag> <gpus> <wait_marker> <beta> [extra trainer args...]
set -u
TAG=$1
GPUS=$2
WAITMARK=$3
BETA=$4
shift 4
BETATAG=${BETA/./}   # 0.5 -> 05, 1 -> 1
export PATH=${OPSD_ROOT:-/root/autodl-tmp}/envs/opsd/bin:$PATH
export HF_HOME=${OPSD_ROOT:-/root/autodl-tmp}/huggingface
export HF_ENDPOINT=https://hf-mirror.com
export HF_HUB_DISABLE_XET=1
export WANDB_MODE=offline
export TOKENIZERS_PARALLELISM=false
export CUDA_VISIBLE_DEVICES=${GPUS}
cd ${OPSD_ROOT:-/root/autodl-tmp}/OPSD

# Wait for the previous queue's LAST unit result file (pollution-proof trigger,
# unlike log markers). Fallback: if this group's GPU stays free for 8 consecutive
# minutes, the previous queue is gone (crashed or finished without producing the
# file) -> proceed. The 8-min threshold safely exceeds inter-unit startup gaps.
if [ "${WAITMARK}" != "none" ]; then
    OWNGPU=${GPUS%%,*}
    FREECNT=0
    echo "=== [${TAG}] waiting for result ${WAITMARK} $(date '+%H:%M:%S') ==="
    while [ ! -f "${OPSD_ROOT:-/root/autodl-tmp}/eval_results_daw/${WAITMARK}" ]; do
        sleep 60
        MEM=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i ${OWNGPU} 2>/dev/null || echo 0)
        if [ "${MEM}" -lt 1000 ]; then FREECNT=$((FREECNT+1)); else FREECNT=0; fi
        if [ ${FREECNT} -ge 8 ]; then
            echo "=== [${TAG}] GPU group free for 8min, previous queue presumed done/gone, proceeding $(date '+%H:%M:%S') ==="
            break
        fi
    done
fi

RUNCFG="qwen31b_${TAG}_gen1024_fixteacher_temp11_forwardbeta${BETATAG}_clip005"
OUT="${OPSD_ROOT:-/root/autodl-tmp}/opsd_daw_outputs/${RUNCFG}"
PORT=12989
case "${GPUS}" in 4*) PORT=13019 ;; esac

# Idempotency: skip training if checkpoint-300 already exists
if [ ! -f "${OUT}/checkpoint-300/trainer_state.json" ]; then
    rm -rf "${OUT}"
    echo "=== [${TAG}] long train start $(date '+%H:%M:%S') gpus=${GPUS} beta=${BETA} ==="
    nohup accelerate launch \
        --config_file accelerate_a800x8.yaml \
        --num_processes 4 \
        --gradient_accumulation_steps 1 \
        --main_process_port ${PORT} \
        opsd_train.py \
        --model_name_or_path ${OPSD_ROOT:-/root/autodl-tmp}/models/Qwen3-1.7B \
        --learning_rate 5e-6 \
        --max_grad_norm 0.1 \
        --per_device_train_batch_size 8 \
        --gradient_checkpointing \
        --gradient_accumulation_steps 1 \
        --output_dir ${OPSD_ROOT:-/root/autodl-tmp}/opsd_daw_outputs/ \
        --run_config "${RUNCFG}" \
        --num_train_epochs 30 \
        --max_completion_length 1024 \
        --save_steps 50 \
        --logging_steps 2 \
        --attn_implementation flash_attention_2 \
        --torch_dtype bfloat16 \
        --max_length 20000 \
        --beta ${BETA} \
        --use_vllm \
        --vllm_mode colocate \
        --vllm_gpu_memory_utilization 0.5 \
        --vllm_tensor_parallel_size 1 \
        --use_peft \
        --lora_r 64 \
        --lora_alpha 128 \
        --lora_target_modules q_proj k_proj v_proj o_proj gate_proj up_proj down_proj \
        --temperature 1.1 \
        --top_p 0.95 \
        --top_k 20 \
        --lmbda 1 \
        --jsd_token_clip 0.05 \
        --fixed_teacher \
        "$@" \
        --wandb_project OPSD \
        > "${OPSD_ROOT:-/root/autodl-tmp}/opsd_${TAG}.log" 2>&1 &

    while [ ! -f "${OUT}/checkpoint-300/trainer_state.json" ]; do
        sleep 30
        if ! pgrep -f "${RUNCFG}" > /dev/null; then
            echo "=== [${TAG}] TRAINING_CRASHED $(date '+%H:%M:%S') ==="
            exit 1
        fi
    done
    sleep 30
    pkill -TERM -f "${RUNCFG}" 2>/dev/null; sleep 5
    pkill -TERM -f "${RUNCFG}" 2>/dev/null; sleep 15
    pkill -KILL -f "${RUNCFG}" 2>/dev/null; sleep 10
    echo "=== [${TAG}] stopped after checkpoint-300 $(date '+%H:%M:%S') ==="
else
    echo "=== [${TAG}] checkpoint-300 exists, skip training $(date '+%H:%M:%S') ==="
fi

# Eval endpoints (300 first = higher priority; 200 for the curve). Skip existing.
if [ ! -f "${OPSD_ROOT:-/root/autodl-tmp}/eval_results_daw/${TAG}_300_hmmt25.json" ]; then
    bash ${OPSD_ROOT:-/root/autodl-tmp}/OPSD/eval/eval_ckpt.sh "${OUT}/checkpoint-300" "${TAG}_300" "${GPUS}"
fi
if [ ! -f "${OPSD_ROOT:-/root/autodl-tmp}/eval_results_daw/${TAG}_200_hmmt25.json" ]; then
    bash ${OPSD_ROOT:-/root/autodl-tmp}/OPSD/eval/eval_ckpt.sh "${OUT}/checkpoint-200" "${TAG}_200" "${GPUS}"
fi
echo "=== [${TAG}] long unit done $(date '+%H:%M:%S') ==="
