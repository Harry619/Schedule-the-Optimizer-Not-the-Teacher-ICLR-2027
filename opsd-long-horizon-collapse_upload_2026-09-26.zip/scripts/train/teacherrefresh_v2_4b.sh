#!/bin/bash
# teacherrefresh v2 (fixed callback): 300-step run with teacher refresh every
# 100 steps, then evaluate the MERGED full models saved at step 200 and 300
# (adapter checkpoints are meaningless for this experiment).
# Usage: bash teacherrefresh_v2.sh <gpus> <wait_json|none>
set -u
GPUS=$1
WAITJSON=$2
export PATH=${OPSD_ROOT:-/root/autodl-tmp}/envs/opsd/bin:$PATH
export HF_HOME=${OPSD_ROOT:-/root/autodl-tmp}/huggingface
export HF_ENDPOINT=https://hf-mirror.com
export HF_HUB_DISABLE_XET=1
export WANDB_MODE=offline
export TOKENIZERS_PARALLELISM=false
export CUDA_VISIBLE_DEVICES=${GPUS}
cd ${OPSD_ROOT:-/root/autodl-tmp}/OPSD

if [ "${WAITJSON}" != "none" ]; then
    OWNGPU=${GPUS%%,*}
    FREECNT=0
    echo "=== [4b_teacherrefresh] waiting for ${WAITJSON} $(date '+%H:%M:%S') ==="
    while [ ! -f "${OPSD_ROOT:-/root/autodl-tmp}/eval_results_daw/${WAITJSON}" ]; do
        sleep 60
        MEM=$(nvidia-smi --query-gpu=memory.used --format=csv,noheader,nounits -i ${OWNGPU} 2>/dev/null || echo 0)
        if [ "${MEM}" -lt 1000 ]; then FREECNT=$((FREECNT+1)); else FREECNT=0; fi
        if [ ${FREECNT} -ge 8 ]; then
            echo "=== [4b_teacherrefresh] own GPU free 8min, proceeding $(date '+%H:%M:%S') ==="
            break
        fi
    done
fi

TAG=4b_teacherrefresh
RUNCFG="qwen34b_${TAG}_gen1024_fixteacher_temp11_forwardbeta0_clip005"
OUT="${OPSD_ROOT:-/root/autodl-tmp}/opsd_daw_outputs/${RUNCFG}"
PORT=12989
case "${GPUS}" in 4*) PORT=13019 ;; esac

if [ ! -f "${OUT}/merged_step300/config.json" ]; then
    rm -rf "${OUT}"
    echo "=== [${TAG}] train start $(date '+%H:%M:%S') gpus=${GPUS} ==="
    nohup accelerate launch \
        --config_file accelerate_a800x8.yaml \
        --num_processes 4 \
        --gradient_accumulation_steps 1 \
        --main_process_port ${PORT} \
        opsd_train.py \
        --model_name_or_path ${OPSD_ROOT:-/root/autodl-tmp}/models/Qwen3-4B \
        --learning_rate 5e-6 \
        --max_grad_norm 0.1 \
        --per_device_train_batch_size 8 \
        --gradient_checkpointing \
        --gradient_accumulation_steps 1 \
        --output_dir ${OPSD_ROOT:-/root/autodl-tmp}/opsd_daw_outputs/ \
        --run_config "${RUNCFG}" \
        --num_train_epochs 30 \
        --max_completion_length 1024 \
        --save_steps 50 \
        --logging_steps 2 \
        --attn_implementation flash_attention_2 \
        --torch_dtype bfloat16 \
        --max_length 20000 \
        --beta 0 \
        --use_vllm \
        --vllm_mode colocate \
        --vllm_gpu_memory_utilization 0.4 \
        --vllm_tensor_parallel_size 1 \
        --use_peft \
        --lora_r 64 \
        --lora_alpha 128 \
        --lora_target_modules q_proj k_proj v_proj o_proj gate_proj up_proj down_proj \
        --temperature 1.1 \
        --top_p 0.95 \
        --top_k 20 \
        --lmbda 1 \
        --jsd_token_clip 0.05 \
        --fixed_teacher \
        --teacher_refresh_every 100 \
        --seed 42 \
        --wandb_project OPSD \
        > "${OPSD_ROOT:-/root/autodl-tmp}/opsd_${TAG}.log" 2>&1 &

    # Wait until merged_step300 exists (saved during the step-300 refresh, which
    # precedes the checkpoint-300 write), with crash guard
    while [ ! -f "${OUT}/merged_step300/config.json" ]; do
        sleep 30
        if ! pgrep -f "${RUNCFG}" > /dev/null; then
            echo "=== [${TAG}] TRAINING_CRASHED $(date '+%H:%M:%S') ==="
            exit 1
        fi
    done
    sleep 20
    pkill -TERM -f "${RUNCFG}" 2>/dev/null; sleep 5
    pkill -KILL -f "${RUNCFG}" 2>/dev/null; sleep 10
    echo "=== [${TAG}] stopped after step-300 refresh $(date '+%H:%M:%S') ==="
else
    echo "=== [${TAG}] merged_step300 exists, skip training $(date '+%H:%M:%S') ==="
fi

# Evaluate the merged full models (endpoint 300 first, then 200)
if [ ! -f "${OPSD_ROOT:-/root/autodl-tmp}/eval_results_daw/${TAG}_300_hmmt25.json" ]; then
    bash ${OPSD_ROOT:-/root/autodl-tmp}/OPSD/scripts/eval_fullmodel.sh "${OUT}/merged_step300" "${TAG}_300" "${GPUS}"
fi
if [ ! -f "${OPSD_ROOT:-/root/autodl-tmp}/eval_results_daw/${TAG}_200_hmmt25.json" ]; then
    bash ${OPSD_ROOT:-/root/autodl-tmp}/OPSD/scripts/eval_fullmodel.sh "${OUT}/merged_step200" "${TAG}_200" "${GPUS}"
fi
echo "=== [${TAG}] unit done $(date '+%H:%M:%S') ==="
