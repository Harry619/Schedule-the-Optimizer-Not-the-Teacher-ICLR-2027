import sys, os
sys.path.insert(0, os.environ.get('OPSD_ROOT', os.path.join(os.path.dirname(__file__), '..', '..')))
from opsd_trainer import OPSDTrainer

# boxed extraction tests
t1 = r"so the answer is \boxed{\frac{3}{2}}. done"
t2 = r"first \boxed{5} then final \boxed{42}"   # must take the LAST one
t3 = "no box here"
print("extract1:", repr(OPSDTrainer._extract_boxed_answer(t1)))
print("extract2:", repr(OPSDTrainer._extract_boxed_answer(t2)))
print("extract3:", repr(OPSDTrainer._extract_boxed_answer(t3)))

# reward tests (instance method; create uninitialized instance shell)
inst = OPSDTrainer.__new__(OPSDTrainer)
comps = [r"the answer is \boxed{25}", "no boxed answer", r"I get \boxed{1/2}", r"answer: \boxed{E}"]
gts   = ["25", "25", r"\frac{1}{2}", "E"]
print("rewards:", inst._compute_rlvr_rewards(comps, gts))
print("SMOKE_OK")
