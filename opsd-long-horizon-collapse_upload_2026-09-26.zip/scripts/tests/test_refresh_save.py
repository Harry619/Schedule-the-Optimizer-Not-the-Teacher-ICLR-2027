"""Reproduce the teacher-refresh merged-save failure on CPU (no GPU needed)."""
import math, os, torch, traceback
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import get_peft_model, LoraConfig

OUT = os.environ.get("OPSD_TEST_OUT", "./refresh_save_test")
os.makedirs(OUT, exist_ok=True)
MODEL = os.environ.get("OPSD_BASE_MODEL", "/path/to/Qwen3-1.7B")

print("loading model...")
model = AutoModelForCausalLM.from_pretrained(MODEL, torch_dtype=torch.bfloat16)
peft_config = LoraConfig(
    r=64, lora_alpha=128,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
)
model = get_peft_model(model, peft_config)

# simulate refresh: merge, reinit, unmerge, then clean-save
model.merge_adapter()
for name, param in model.named_parameters():
    if "lora_A" in name:
        torch.nn.init.kaiming_uniform_(param.data, a=math.sqrt(5))
    elif "lora_B" in name:
        param.data.zero_()
model.unmerge_adapter()

try:
    from safetensors.torch import save_file
    base_model = model.get_base_model()
    clean_sd = {}
    for k, v in base_model.state_dict().items():
        if "lora_" in k:
            continue
        clean_sd[k.replace(".base_layer.weight", ".weight").replace(".base_layer.bias", ".bias")] = v
    save_file(clean_sd, os.path.join(OUT, "model.safetensors"), metadata={"format": "pt"})
    base_model.config.save_pretrained(OUT)
    print("CLEAN_SAVE_OK", len(clean_sd))
except Exception as e:
    print("CLEAN_SAVE_FAILED:")
    traceback.print_exc()
