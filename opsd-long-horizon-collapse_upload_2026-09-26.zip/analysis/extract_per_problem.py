#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Extract compact per-problem scores from raw evaluation JSONs.

The raw per-problem evaluation JSONs produced by eval/evaluate_math.py contain
full generations (tens of MB per file). This script strips generations/problem
text and keeps only the fields needed for the paper's statistical analyses
(paired bootstrap, difficulty stratification, format-rate tables):

    per problem: problem_id, val_n, num_correct, pass_at_n,
                 majority_vote_correct, formatted
    per file:    protocol metadata + aggregate metrics

Usage:
    python extract_per_problem.py <raw_eval_dir> <out.json>

The shipped `per_problem_scores.json` was generated with this script from the
full raw set; regenerate it if you re-run evaluations yourself.
"""
import json, glob, os, sys

RAW = sys.argv[1] if len(sys.argv) > 1 else os.environ.get("OPSD_EVAL_DIR", "eval_results")
OUT = sys.argv[2] if len(sys.argv) > 2 else "per_problem_scores.json"

KEEP_META = ["base_model", "dataset", "enable_thinking", "temperature", "top_p",
             "top_k", "min_p", "presence_penalty", "max_new_tokens", "val_n",
             "num_problems", "total_solutions", "pass_at_n", "pass_at_n_pct",
             "average_at_n", "average_at_n_pct", "majority_vote_at_n",
             "majority_vote_at_n_pct", "formatted_count", "format_rate"]

out = {}
for f in sorted(glob.glob(os.path.join(RAW, "*.json"))):
    tag = os.path.basename(f)[:-5]
    d = json.load(open(f, encoding="utf-8"))
    entry = {"meta": {k: d.get(k) for k in KEEP_META}, "problems": {}}
    for it in d.get("results", []):
        pid = str(it["problem_id"])
        entry["problems"][pid] = {
            "val_n": it["val_n"],
            "num_correct": it["num_correct"],
            "pass_at_n": it["pass_at_n"],
            "majority_vote_correct": it["majority_vote_correct"],
            "formatted": it.get("formatted"),
        }
    out[tag] = entry
    print(f"[extract] {tag}: {len(entry['problems'])} problems")

json.dump(out, open(OUT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"[extract] wrote {OUT}: {len(out)} files, "
      f"{os.path.getsize(OUT)/1e6:.1f} MB")
