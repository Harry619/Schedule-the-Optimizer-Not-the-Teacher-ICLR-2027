#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Canonical paired-bootstrap CIs for the paper (single source of truth).

Identical protocol and pair list to the canonical 2026-09-15 run
(analysis_0915.py), but reads the compact `per_problem_scores.json`
(0.8 MB, shipped in this repo) instead of the raw per-problem evaluation
JSONs (~3.5 GB, regenerable via eval/evaluate_math.py + extract_per_problem.py).
The two clip-removed pairs at the end of PAIRS were appended after that run
(same protocol, continued on the same RNG stream); in the paper's CI table
they sit inside the 1.7B block, so the script emits all 24 rows of Table 9.

Protocol:
  - paired bootstrap over the 90 competition problems (aime24+aime25+hmmt25),
    aligned problem-by-problem (problem_id), 10,000 resamples,
    numpy default_rng(2026), percentile 95% CIs.

Usage:  python bootstrap_canonical.py
Expected output matches the shipped bootstrap_canonical_0915.json exactly.
"""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))
SCORES = json.load(open(os.path.join(HERE, 'per_problem_scores.json'), encoding='utf-8'))
BENCH = ['aime24', 'aime25', 'hmmt25']

# ---------------------------------------------------------------- helpers
def per_problem(tag):
    """{problem_id: accuracy in [0,1]} pooled over the three benchmarks."""
    out = {}
    for b in BENCH:
        j = SCORES[f'{tag}_{b}']
        for pid, it in j['problems'].items():
            key = f'{b}:{pid}'
            assert key not in out
            out[key] = it['num_correct'] / it['val_n']
    assert len(out) == 90, (tag, len(out))
    return out

CACHE = {}
def get(tag):
    if tag not in CACHE:
        CACHE[tag] = per_problem(tag)
    return CACHE[tag]

import numpy as np

def paired_boot(tagA, tagB, n_boot=10_000, rng=None):
    a, b = get(tagA), get(tagB)
    pids = sorted(a)
    da = np.array([a[p] for p in pids])
    db = np.array([b[p] for p in pids])
    n = len(pids)
    point = float((da.mean() - db.mean()) * 100)
    if rng is None:
        return point, None, None
    idx = rng.integers(0, n, size=(n_boot, n))
    diffs = (da[idx].mean(axis=1) - db[idx].mean(axis=1)) * 100
    lo, hi = np.percentile(diffs, [2.5, 97.5])
    return point, float(lo), float(hi)

# ------------------------------------------------- canonical pair list (fixed)
PAIRS = [
    # (label, scale, tagA, tagB, published_point_for_verification)
    ('const vs base',        '1.7B', 'baseline_long_300',  'base',               -3.0),
    ('const vs peak(75)',    '1.7B', 'baseline_long_300',  'baseline75',         -7.4),
    ('decay vs const',       '1.7B', 'lrdecay_300',        'baseline_long_300',  +4.2),
    ('decay vs base',        '1.7B', 'lrdecay_300',        'base',               +1.2),
    ('linear vs cosine',     '1.7B', 'lineardecay_300',    'lrdecay_300',        -0.1),
    ('DAW vs const',         '1.7B', 'bandpass_long_300',  'baseline_long_300',  -0.6),
    ('hybrid vs const',      '1.7B', 'hybridv2_long_300',  'baseline_long_300',  -1.7),
    ('refresh vs const',     '1.7B', 'teacherrefreshv2_300','baseline_long_300', -29.4),
    ('const-1/2LR vs decay', '1.7B', 'const2p5e6_300',     'lrdecay_300',        None),
    ('DAW+decay vs decay',   '1.7B', 'dawdecay_300',       'lrdecay_300',        None),
    ('symclip vs const',     '1.7B', 'symclip_300',        'baseline_long_300',  None),
    ('EMA0.99 vs const',     '1.7B', 'ema0099_300',        'baseline_long_300',  None),
    ('refresh200 vs const',  '1.7B', 'refresh200_300',     'baseline_long_300',  None),
    ('fp32 vs const',        '1.7B', 'fp32_300',           'baseline_long_300',  None),
    ('const vs base',        '4B',   '4b_baseline_long_300','4b_base',           -9.1),
    ('decay vs const',       '4B',   '4b_lrdecay_long_300','4b_baseline_long_300', +5.3),
    ('decay vs base',        '4B',   '4b_lrdecay_long_300','4b_base',            -3.8),
    ('refresh vs const',     '4B',   '4b_teacherrefresh_300','4b_baseline_long_300', -47.8),
    ('const vs base',        '8B',   '8b_baseline_long_300','8b_base',           -5.4),
    ('decay vs const',       '8B',   '8b_lrdecay_300',     '8b_baseline_long_300', +5.3),
    ('decay vs base',        '8B',   '8b_lrdecay_300',     '8b_base',            -0.1),
    ('DAW vs const',         '8B',   '8b_bandpass_long_300','8b_baseline_long_300', -0.8),
    # appended after the 0915 canonical run (Table 9 1.7B block, last two rows);
    # appended at the END here so the RNG stream over pairs 1-22 is unchanged
    ('clip removed vs const','1.7B', 'noclip_300',         'baseline_long_300',   -1.4),
    ('clip removed vs base', '1.7B', 'noclip_300',         'base',                -4.4),
]

rng = np.random.default_rng(2026)
out_rows = []
print(f'\n{"pair":24s} {"scale":5s} {"delta":>7s}  {"95% CI":>18s}  verify')
for label, scale, ta, tb, pub in PAIRS:
    point, lo, hi = paired_boot(ta, tb, rng=rng)
    ok = ''
    if pub is not None:
        ok = 'OK' if abs(point - pub) < 0.055 else f'MISMATCH pub={pub}'
    print(f'{label:24s} {scale:5s} {point:+7.2f}  [{lo:+6.2f}, {hi:+6.2f}]  {ok}')
    out_rows.append({'pair': label, 'scale': scale, 'A': ta, 'B': tb,
                     'delta': round(point, 2), 'lo': round(lo, 2), 'hi': round(hi, 2),
                     'published_point': pub})

with open(os.path.join(HERE, 'bootstrap_canonical_0915.json'), 'w', encoding='utf-8') as fh:
    json.dump({'protocol': 'paired problem bootstrap, 90 problems, 10000 draws, '
                           'default_rng(2026), percentile CI',
               'pairs': out_rows}, fh, ensure_ascii=False, indent=1)
print('\nwritten: analysis/bootstrap_canonical_0915.json '
      '(identical to the shipped canonical file)')
