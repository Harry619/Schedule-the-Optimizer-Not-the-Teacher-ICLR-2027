# -*- coding: utf-8 -*-
"""Estimate total compute (A800 GPU-hours) for all OPSD paper runs.

Method (all numbers traceable to logs/notes; 4B/8B step times extrapolated):
  - Enumerate run families from compact_results.json (checkpoint tags stripped).
  - Training anchors (measured):
      4-GPU main config : 300 steps = 2617-2632 s  -> 8.73 s/it   (opsd_lrdecay.log,
                          opsd_refreshdecay.log train_runtime)
      2-GPU queue config: 300 steps = 7758-7964 s  -> 26.4 s/it   (dawdecay_300_s*,
                          symclip laneA timestamps 08:39->10:53 = 8041 s)
      8-GPU initial run : 6.8 s/it                                (ai_usage_log 8/30)
  - 4B/8B step time = 1.7B x params ratio (2.35 / 4.7)  [EXTRAPOLATION, flagged]
  - Eval anchors (measured, queue lane TP2 timestamps):
      one 30-problem x12 benchmark = 84-116 min on 2 GPUs
      -> ~4.6 h per 3-benchmark checkpoint ~= 9.2 GPU.h (assumed ~10 GPU.h on TP4)
      MATH500 val_n=4 (2000 gens, shorter traces) ~ 10 GPU.h [ESTIMATE]
Output: per-category table + totals.
"""
import json, re, collections, os

HERE = os.path.dirname(os.path.abspath(__file__))
j = json.load(open(os.path.join(HERE, "compact_results.json"), encoding="utf-8"))
RES = j["results"]

BENCH = ("aime24", "aime25", "hmmt25", "math500")

# ---- family extraction ----------------------------------------------------
runs = collections.defaultdict(set)   # family -> set of datasets evaluated
for k in RES:
    m = re.match(r"(.+?)_(aime24|aime25|hmmt25|math500)$", k)
    if m:
        runs[m.group(1)].add(m.group(2))

SPECIAL_STEPS = {"matched100": 100, "matched300": 300}   # two separate runs

fams = collections.defaultdict(set)    # family -> checkpoint steps evaluated
for tag in runs:
    if tag.endswith("_m4"):            # MATH500 marker, same checkpoint as comp.
        tag = tag[:-3]
    m = re.match(r"^(.*?)_s([12])(?:_(\d+))?$", tag)     # seed-suffixed run
    if m:
        fams[m.group(1) + "_s" + m.group(2)].add(int(m.group(3) or 300))
        continue
    m = re.match(r"^(.*?)_(\d+)$", tag)                  # ..._NNN
    if m:
        fams[m.group(1)].add(int(m.group(2)))
        continue
    m = re.match(r"^(.*?)(\d+)$", tag)                   # ...NNN (no underscore)
    if m and not tag.endswith("s1") and not tag.endswith("s2"):
        fams[m.group(1)].add(int(m.group(2)))
        continue
    fams[tag].add(0)                   # eval-only (base models)
if fams.get("matched"):                # matched100/matched300 are two runs
    fams["matched100"], fams["matched300"] = {100}, {300}
    fams.pop("matched")

# ---- classification -------------------------------------------------------
SIT_4GPU = 8.73      # s/it, 1.7B, 4x A800 (measured)
SIT_2GPU = 26.4      # s/it, 1.7B, 2x A800 (measured)
SCALE_FACTOR = {"1.7b": 1.0, "4b": 2.35, "8b": 4.7}   # extrapolation

TWO_GPU_FAMS = {  # ran in the 2-GPU queue era (lane A/B + multiseed2gpu_queue)
    "symclip", "symclip_300_s1", "symclip_300_s2",
    "dawdecay", "dawdecay_300_s1", "dawdecay_300_s2",
    "matched100", "matched300", "const2p5e6", "refresh200", "fp32",
    "ema0099", "ema09995", "lrdecay_300_s1", "lrdecay_300_s2",
    "baseline_300_s1", "baseline_300_s2", "smoke_matched",
}

def scale_of(fam):
    if fam.startswith("4b_"): return "4b"
    if fam.startswith("8b_"): return "8b"
    return "1.7b"

train_rows, eval_count = [], collections.Counter()
for fam, steps in sorted(fams.items()):
    sc = scale_of(fam)
    maxstep = max(steps)
    if maxstep == 0:
        continue    # eval-only family (base)
    if fam == "decay500":
        maxstep = 500
    sit = SIT_2GPU if fam in TWO_GPU_FAMS else SIT_4GPU
    if fam in TWO_GPU_FAMS and sc != "1.7b":
        sit = SIT_4GPU
    sit *= SCALE_FACTOR[sc]
    wall_h = maxstep * sit / 3600.0
    ngpu = 2 if fam in TWO_GPU_FAMS else 4
    train_rows.append((fam, sc, maxstep, ngpu, wall_h, wall_h * ngpu))

# eval counting: every (tag, dataset) entry = one benchmark eval
comp_evals, m500_evals = 0, 0
for tag, dss in runs.items():
    for ds in dss:
        if ds == "math500":
            m500_evals += 1
        else:
            comp_evals += 1

# ---- totals ----------------------------------------------------------------
GPUH_EVAL3 = 9.5    # GPU.h per 3-benchmark checkpoint eval (measured 9.2 on TP2)
GPUH_M500 = 10.0    # GPU.h per MATH500 val_n=4 eval (estimate)

by_scale = collections.defaultdict(lambda: [0.0, 0, 0.0])
for fam, sc, st, ng, wall, gpuh in train_rows:
    by_scale[sc][0] += gpuh
    by_scale[sc][1] += 1
tot_train_gpuh = sum(r[5] for r in train_rows)
tot_train_wall = sum(r[4] for r in train_rows)

print("== training runs ==")
for fam, sc, st, ng, wall, gpuh in train_rows:
    print(f"{fam:28s} {sc:4s} {st:3d}st x{ng}GPU  wall={wall:6.2f}h  gpuh={gpuh:7.2f}")
print(f"\nfamilies={len(train_rows)}  wall_sum={tot_train_wall:.1f}h  train_gpuh={tot_train_gpuh:.0f}")
for sc in ("1.7b", "4b", "8b"):
    print(f"  {sc}: {by_scale[sc][1]} runs, {by_scale[sc][0]:.0f} GPU.h")

eval_gpuh = comp_evals / 3.0 * GPUH_EVAL3 + m500_evals * GPUH_M500
print(f"\n== evals ==\ncompetition benchmark evals={comp_evals} "
      f"(~{comp_evals/3:.0f} checkpoints x3)\nMATH500 evals={m500_evals}")
print(f"eval_gpuh={eval_gpuh:.0f}  (at {GPUH_EVAL3}/ckpt + {GPUH_M500}/m500)")
print(f"\n== TOTAL ~= {tot_train_gpuh + eval_gpuh:.0f} A800 GPU.h "
      f"(train {tot_train_gpuh:.0f} + eval {eval_gpuh:.0f})")
