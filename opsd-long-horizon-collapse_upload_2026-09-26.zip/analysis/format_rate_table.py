# -*- coding: utf-8 -*-
"""Format-rate table for Appendix H.7 ("is the collapse an evaluation artifact?").

Reads the shipped per_problem_scores.json and reports the
boxed-answer format rate (formatted_count / total_solutions) for the runs the
argument needs. Numbers are per-benchmark (30 problems x 12 samples = 360
generations each) plus the mean over the three benchmarks.
Output: printed table + dumped JSON (traceability).
"""
import json, glob, os

HERE = os.path.dirname(os.path.abspath(__file__))
SCORES = json.load(open(os.path.join(HERE, "per_problem_scores.json"), encoding="utf-8"))
BENCH = ("aime24", "aime25", "hmmt25")

# (row label, run tag) -- grouped as the LaTeX table will show them
ROWS = [
    ("1.7B base",                    "base"),
    ("1.7B step-100 (constant LR)",  "baseline100"),
    ("1.7B step-300 constant LR",    "baseline_long_300"),
    ("1.7B step-300 cosine decay",   "lrdecay_300"),
    ("1.7B refresh step-300",        "teacherrefreshv2_300"),
    ("4B base",                      "4b_base"),
    ("4B step-100 (constant LR)",    "4b_baseline_100"),
    ("4B step-300 constant LR",      "4b_baseline_long_300"),
    ("4B step-300 cosine decay",     "4b_lrdecay_long_300"),
    ("4B refresh step-200",          "4b_teacherrefresh_200"),
    ("4B refresh step-300",          "4b_teacherrefresh_300"),
    ("8B base",                      "8b_base"),
    ("8B step-300 constant LR",      "8b_baseline_long_300"),
    ("8B step-300 cosine decay",     "8b_lrdecay_300"),
]

out = {}
for label, tag in ROWS:
    per = []
    for b in BENCH:
        j = SCORES[f"{tag}_{b}"]["meta"]
        per.append(round(j["format_rate"], 1))
    out[label] = {"tag": tag, "per_benchmark": per,
                  "mean": round(sum(per) / 3.0, 1)}
    print(f"{label:32s} {per[0]:6.1f} {per[1]:6.1f} {per[2]:6.1f}   mean {out[label]['mean']:6.1f}")

# sanity: every non-refresh row >= 94, refresh rows low
nonref = [v["mean"] for k, v in out.items() if "refresh" not in k]
print(f"\nnon-refresh min format rate: {min(nonref)}")

with open(os.path.join(HERE, "format_rate_table.json"), "w", encoding="utf-8") as fh:
    json.dump(out, fh, indent=1, ensure_ascii=False)
print("dumped format_rate_table.json")
