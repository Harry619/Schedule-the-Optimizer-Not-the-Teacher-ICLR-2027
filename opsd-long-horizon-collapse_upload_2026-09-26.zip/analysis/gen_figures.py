#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Generate all paper figures from eval_results JSONs and training logs.
All numbers are traceable to ../data/eval_results/*.json and ../data/logs/*.
Usage: python gen_figures.py
"""
import json, glob, os, re, collections
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
LOGS = os.path.join(HERE, "logs")
BENCH = ["aime24", "aime25", "hmmt25"]

with open(os.path.join(HERE, "compact_results.json"), encoding="utf-8") as _fh:
    _COMPACT = json.load(_fh)
RES = _COMPACT["results"]

plt.rcParams.update({
    "font.size": 9, "axes.titlesize": 9.5, "axes.labelsize": 9,
    "legend.fontsize": 8, "xtick.labelsize": 8, "ytick.labelsize": 8,
    "figure.dpi": 150, "savefig.bbox": "tight",
})
C = {"baseline": "#4C72B0", "bandpass": "#55A868", "hybridv2": "#C44E52",
     "lrdecay": "#8172B3", "refresh": "#937860", "base": "#888888"}

def avg_at_n(tag):
    """mean Avg@12 across the three benchmarks; None if any missing."""
    vals = []
    for ds in BENCH:
        e = RES.get(f"{tag}_{ds}")
        if e is None or e.get("avg_at_n_pct") is None:
            return None
        vals.append(e["avg_at_n_pct"])
    return sum(vals) / len(vals)

def math500(tag):
    e = RES.get(f"{tag}_math500")
    return e["avg_at_n_pct"] if e else None

# ---------------------------------------------------------------- Fig 1: collapse curves
def fig1():
    series = {
        "baseline (frozen teacher)": (["baseline25", "baseline50", "baseline75", "baseline100", "baseline_long_200", "baseline_long_300"], C["baseline"], "o"),
        "DAW bandpass": (["bandpass25", "bandpass50", "bandpass75", "bandpass100", "bandpass_long_200", "bandpass_long_300"], C["bandpass"], "s"),
        "OPSD+RLVR hybrid": (["hybridv2_100", "hybridv2_long_200", "hybridv2_long_300"], C["hybridv2"], "^"),
    }
    steps_map = {"25": 25, "50": 50, "75": 75, "100": 100, "200": 200, "300": 300}
    fig, ax = plt.subplots(figsize=(5.6, 3.05))
    for name, (tags, color, mk) in series.items():
        xs, ys = [], []
        for t in tags:
            v = avg_at_n(t)
            if v is not None:
                m = re.search(r"(\d+)$", t)
                xs.append(steps_map[m.group(1)] if m else int(m.group(1)))
                ys.append(v)
        ax.plot(xs, ys, marker=mk, color=color, label=name, lw=1.5, ms=4)
    ax.axhline(avg_at_n("base"), color=C["base"], ls="--", lw=1.2, label="base model")
    ax.axvspan(0, 100, color="0.92", zorder=0)
    ax.text(50, ax.get_ylim()[0] + 0.4, "original study's\n100-step budget",
            ha="center", va="bottom", fontsize=7, color="0.45")
    ax.set_xlabel("training steps"); ax.set_ylabel("Avg@12 (mean of 3 bench.)")
    ax.set_title("Long-horizon collapse of frozen-teacher OPSD (Qwen3-1.7B)")
    # legend goes upper right: the lower-left corner collides with the
    # budget note, and the upper left is occupied by the rising curves
    ax.legend(frameon=False, loc="upper right")
    ax.grid(alpha=0.25)
    fig.savefig(os.path.join(HERE, "fig1_collapse_curve.pdf"))
    plt.close(fig)

# ---------------------------------------------------------------- Fig 2: mechanism discrimination
def fig2():
    groups = [("baseline", "baseline_long", C["baseline"]),
              ("cosine LR decay", "lrdecay", C["lrdecay"]),
              ("teacher refresh", "teacherrefreshv2", C["refresh"])]
    steps = [200, 300]
    fig, ax = plt.subplots(figsize=(4.6, 3.0))
    w = 0.25
    for i, (name, prefix, color) in enumerate(groups):
        vals = [avg_at_n(f"{prefix}_{s}") for s in steps]
        x = np.arange(len(steps)) + (i - 1) * w
        ax.bar(x, [v if v is not None else 0 for v in vals], width=w, color=color, label=name)
        for xi, v in zip(x, vals):
            if v is not None:
                ax.text(xi, v + 0.6, f"{v:.1f}", ha="center", fontsize=7.5)
    # split legend: three color groups top-right, the two reference lines
    # top-left -- one five-row box reached down to the dotted 41.0 line
    # and the bar labels
    leg_groups = ax.legend(frameon=False, fontsize=7.5, loc="upper right")
    ax.add_artist(leg_groups)
    l_base = ax.axhline(avg_at_n("base"), color=C["base"], ls="--", lw=1.2)
    l_b100 = ax.axhline(avg_at_n("baseline100"), color=C["baseline"], ls=":", lw=1.2)
    ax.legend([l_base, l_b100], ["base model", "baseline step-100"],
              frameon=False, fontsize=7.5, loc="upper left")
    ax.set_xticks(np.arange(len(steps))); ax.set_xticklabels([f"step {s}" for s in steps])
    ax.set_ylabel("Avg@12 (mean of 3 bench.)"); ax.set_ylim(0, 60)
    ax.set_title("Mechanism discrimination at longer horizon (1.7B)")
    ax.grid(alpha=0.25, axis="y")
    fig.savefig(os.path.join(HERE, "fig2_mechanism.pdf"))
    plt.close(fig)

# ---------------------------------------------------------------- Fig 3: multi-seed step-100
def fig3():
    methods = [("baseline", ["baseline100", "baseline_s1_100", "baseline_s2_100"], C["baseline"]),
               ("DAW bandpass", ["bandpass100", "bandpass_s1_100", "bandpass_s2_100"], C["bandpass"]),
               ("OPSD+RLVR hybrid", ["hybridv2_100", "hybridv2_s1_100", "hybridv2_s2_100"], C["hybridv2"])]
    fig, ax = plt.subplots(figsize=(4.6, 3.0))
    w = 0.25
    for i, (name, tags, color) in enumerate(methods):
        vals = [avg_at_n(t) for t in tags]
        vals = [v for v in vals if v is not None]
        mean = np.mean(vals)
        ax.bar(i, mean, width=0.5, color=color, alpha=0.85)
        ax.scatter([i - w, i, i + w], vals, color="black", s=12, zorder=5)
        ax.text(i, mean + 0.7, f"{mean:.1f}±{np.std(vals):.1f}", ha="center",
                va="bottom", fontsize=8)
        ax.plot([i - w, i + w], [mean, mean], color="black", lw=1)
    ax.axhline(avg_at_n("base"), color=C["base"], ls="--", lw=1.2)
    ax.set_xticks(range(len(methods))); ax.set_xticklabels([m[0] for m in methods])
    ax.set_ylabel("Avg@12, step-100 (3 seeds)")
    # explicit ylim: headroom so the mean labels clear their mean lines
    # without poking the top spine
    ax.set_ylim(37.5, 43.6)
    ax.set_title("Multi-seed comparison at step 100 (1.7B)")
    # the dashed line is explained by a word label just outside the right
    # spine -- an in-axes legend box only ever sat on the baseline bar
    ax.text(1.015, avg_at_n("base"), "base model",
            transform=ax.get_yaxis_transform(), ha="left", va="center",
            fontsize=7.5, color=C["base"], clip_on=False)
    ax.grid(alpha=0.25, axis="y")
    fig.savefig(os.path.join(HERE, "fig3_multiseed.pdf"))
    plt.close(fig)

# ---------------------------------------------------------------- Fig 4: 4B replication
def fig4():
    # the two step-300 bars take orange (constant-LR step-300, as in fig7)
    # and brown, so all six bars are distinct colors
    items = [("base", "4b_base", C["base"]),
             ("baseline\nstep-100", "4b_baseline_100", C["baseline"]),
             ("bandpass\nstep-100", "4b_bandpass_100", C["bandpass"]),
             ("baseline\nstep-300", "4b_baseline_long_300", "#DD8452"),
             ("bandpass\nstep-300", "4b_bandpass_long_300", "#937860"),
             ("LR decay\nstep-300", "4b_lrdecay_long_300", C["lrdecay"])]
    fig, ax = plt.subplots(figsize=(4.6, 3.0))
    xs = np.arange(len(items))
    for i, (name, tag, color) in enumerate(items):
        v = avg_at_n(tag)
        ax.bar(i, v if v else 0, width=0.55, color=color)
        if v:
            # +2.0 keeps every label clear of the 60.7 base line, which
            # crosses the label band just above the three ~60-point bars
            ax.text(i, v + 2.0, f"{v:.1f}", ha="center", fontsize=8)
    ax.axhline(avg_at_n("4b_base"), color=C["base"], ls="--", lw=1.2)
    ax.set_xticks(xs); ax.set_xticklabels([i[0] for i in items], fontsize=7.5)
    ax.set_ylim(0, 65)
    ax.set_ylabel("Avg@12 (mean of 3 bench.)")
    ax.set_title("Collapse and mitigation replicate at Qwen3-4B")
    ax.grid(alpha=0.25, axis="y")
    fig.savefig(os.path.join(HERE, "fig4_4b.pdf"))
    plt.close(fig)

# ---------------------------------------------------------------- Fig 5: hybrid v1 grad explosion
def fig5():
    steps, norms = [], []
    for line in open(os.path.join(LOGS, "opsd_hybrid_rlvr.log"), errors="replace"):
        m = re.search(r"'grad_norm': ([0-9.e+-]+)", line)
        if m:
            norms.append(float(m.group(1)))
    steps = list(range(len(norms)))
    fig, ax = plt.subplots(figsize=(4.6, 3.0))
    ax.semilogy(steps, norms, lw=1, color=C["hybridv2"], label="grad norm (v1)")
    ax.axhline(0.1, color="black", ls="--", lw=1, label="clip threshold (0.1)")
    ax.set_xlabel("logging step"); ax.set_ylabel("grad norm (log scale)")
    # the log has four full-height spikes (steps 14/15/30/43), so no band
    # inside the axes is wide enough for a legend; it rides in one row
    # just above the top-left corner, under a padded title
    ax.set_title("Gradient explosion in the unhardened RLVR hybrid (v1)",
                 pad=26)
    ax.legend(frameon=False, fontsize=7.5, ncol=2, loc="lower left",
              bbox_to_anchor=(0.0, 1.01), handlelength=1.6,
              columnspacing=1.2, handletextpad=0.5)
    ax.grid(alpha=0.25)
    fig.savefig(os.path.join(HERE, "fig5_grad_explosion.pdf"))
    plt.close(fig)

# ---------------------------------------------------------------- Fig 6: DAW dynamics
def fig6():
    """Unclipped teacher-student divergence, constant vs cosine, from the DAW
    statistics lane.  [DAW] lines are logged per rank, so duplicate lines at
    the same step are averaged.  The lane exists only in DAW runs (whose
    long-horizon fate is statistically indistinguishable from the baseline's),
    so DAW runs carry the divergence meter; log scale so the step-110 batch
    (mean 1.20) stays on-axis instead of being clipped."""
    def daw_stats(fn):
        acc = collections.defaultdict(list)
        for line in open(os.path.join(LOGS, fn), errors="replace"):
            m = re.search(r"\[DAW\] step=(\d+) daw_kl_mean=([0-9.]+) "
                          r"daw_kl_p10=([0-9.]+) daw_kl_p90=([0-9.]+)", line)
            if m:
                acc[int(m.group(1))].append(
                    tuple(float(m.group(i)) for i in (2, 3, 4)))
        steps = sorted(acc)
        cols = [tuple(sum(c) / len(c) for c in zip(*acc[s])) for s in steps]
        mean, p10, p90 = map(np.array, zip(*cols))
        return np.array(steps), mean, p10, p90

    # constant-LR series: full 300-step trajectory from the bandpass_long run
    # (E6, extracted 2026-09-18 from the server log into e6_divergence_full300.json;
    # supersedes the earlier 110-step window from opsd_daw_bandpass.log).
    e6_path = os.path.join(HERE, "e6_divergence_full300.json")
    if not os.path.exists(e6_path):
        e6_path = os.path.join(HERE, "e6_divergence_full300.json")
    e6 = json.load(open(e6_path, encoding="utf-8"))
    tr = e6["trajectory"]
    sc = np.array([p["step"] for p in tr])
    mc = np.array([p["kl_mean"] for p in tr])
    p10c = np.array([p["p10"] for p in tr])
    p90c = np.array([p["p90"] for p in tr])
    sd, md, p10d, p90d = daw_stats("opsd_dawdecay_300.log")  # full 300-step run
    fig, ax = plt.subplots(figsize=(4.6, 3.0))
    ax.semilogy(sc, mc, "-o", ms=3.5, lw=1.5, color=C["baseline"],
                label="constant LR")
    ax.fill_between(sc, p10c, p90c, alpha=0.18, color=C["baseline"])
    ax.semilogy(sd, md, "-s", ms=3.5, lw=1.5, color=C["lrdecay"],
                label="cosine decay")
    ax.fill_between(sd, p10d, p90d, alpha=0.18, color=C["lrdecay"])
    ax.set_xlabel("training step"); ax.set_ylabel("per-sample fwd-KL (unclipped)")
    ax.set_ylim(0.05, 1.9); ax.set_xlim(-6, 300)
    ax.set_title("Unclipped teacher–student divergence: constant vs. cosine")
    ax.legend(frameon=False, fontsize=7.5, loc="upper left")
    ax.grid(alpha=0.25)
    fig.savefig(os.path.join(HERE, "fig6_daw_dynamics.pdf"))
    plt.close(fig)

# ---------------------------------------------------------------- data dump for tables
def dump_table_json():
    with open(os.path.join(HERE, "all_results.json"), "w") as fh:
        json.dump(RES, fh, indent=1)
    print(f"dumped {len(RES)} result entries")

# ---------------------------------------------------------------- Fig 7: scale ladder
def fig7():
    groups = [
        ("1.7B", "base", "baseline100", "baseline_long_300", "lrdecay_300"),
        ("4B", "4b_base", "4b_baseline_100", "4b_baseline_long_300", "4b_lrdecay_long_300"),
        ("8B", "8b_base", "8b_baseline_100", "8b_baseline_long_300", "8b_lrdecay_300"),
    ]
    labels = ["base", "step-100", "step-300 (const. LR)", "step-300 (LR decay)"]
    colors = [C["base"], C["baseline"], "#DD8452", C["lrdecay"]]
    fig, ax = plt.subplots(figsize=(5.6, 3.1))
    w = 0.2
    for gi, (scale, b, s100, s300, s300d) in enumerate(groups):
        for j, tag in enumerate([b, s100, s300, s300d]):
            v = avg_at_n(tag) if tag else None
            x = gi + (j - 1.5) * w
            if v is not None:
                ax.bar(x, v, width=w * 0.92, color=colors[j])
                ax.text(x, v + 0.7, f"{v:.1f}", ha="center", fontsize=7)
    ax.set_xticks(range(len(groups)))
    ax.set_xticklabels([g[0] for g in groups])
    ax.set_ylabel("Avg@12 (mean of 3 bench.)")
    ax.set_ylim(0, 88)
    ax.legend([plt.Rectangle((0,0),1,1,color=colors[j]) for j in range(4)], labels,
              frameon=False, fontsize=7.5, loc="upper left")
    ax.set_title("Collapse across scales, and the decay fix (baseline OPSD)", pad=6)
    ax.grid(alpha=0.25, axis="y")
    fig.savefig(os.path.join(HERE, "fig7_scale_ladder.pdf"))
    plt.close(fig)

# ---------------------------------------------------------------- Fig 8: drift budget
def fig8():
    """Terminal performance vs. cumulative LR dose B = int lr dt.
    Doses in units of peak lr (5e-6) x steps, no warmup:
      constant t:            B = t
      cosine over T, at t:   B = 0.5 [t + (T/pi) sin(pi t/T)]
      linear over T, at T:   B = 0.5 T
    """
    pts = [
        ("baseline100",       100.0, "const. @100",      "const"),
        ("lrdecay_300",       150.0, "cosine-300",       "cos"),
        ("lineardecay_300",   150.0, "linear-300",       "lin"),
        ("const2p5e6_300",    150.0, "const-$\\frac{1}{2}$LR @300", "const"),
        ("decay500_300",      225.7, "cosine-500 @300",  "cos"),
        ("decay500_500",      250.0, "cosine-500 @500",  "cos"),
        ("baseline_long_300", 300.0, "const. @300",      "const"),
        ("baseline_150",      150.0, "const. @150",      "rev"),
    ]
    colmap = {"const": "#DD8452", "cos": C["lrdecay"], "lin": C["bandpass"],
              "rev": "#C44E52"}
    famname = {"const": "constant LR", "cos": "cosine decay",
               "lin": "linear decay", "rev": "reverse unit (same dose, fewer steps)"}
    seen = set()
    offsets = {  # (dx, dy, ha): avoid label collisions at B=150 and right
        # edge.  const.@100 sits clear under the raised ylim top; linear-300
        # is directly below its marker, wedged between the half-LR marker
        # and the base line; const-1/2LR drops to the lower left of the
        # base line; cosine-500@500 hangs above the (lowered) x-axis.
        "const. @100":     (0, 8, "center"),
        "cosine-300":      (8, 7, "left"),
        "linear-300":      (0, -18, "center"),
        "const-$\\frac{1}{2}$LR @300": (-6, -28, "right"),
        "cosine-500 @300": (6, 6, "left"),
        "cosine-500 @500": (0, -13, "center"),
        "const. @300":     (-6, 7, "right"),
        "const. @150":     (0, -15, "center"),
    }
    fig, ax = plt.subplots(figsize=(4.6, 3.0))
    allpts = []
    for tag, b, lbl, fam in pts:
        v = avg_at_n(tag)
        if v is None:
            continue
        ax.scatter(b, v, s=46, color=colmap[fam], zorder=5,
                   marker="x" if fam == "rev" else "o",
                   label=famname[fam] if fam not in seen else None)
        seen.add(fam)
        dx, dy, ha = offsets[lbl]
        ax.annotate(lbl, (b, v), textcoords="offset points",
                    xytext=(dx, dy), fontsize=7.5, ha=ha)
        allpts.append((b, v))
    allpts.sort()
    ax.plot([p[0] for p in allpts], [p[1] for p in allpts], lw=0.9, color="0.6", zorder=1)
    ax.axhline(avg_at_n("base"), color=C["base"], ls="--", lw=1.2)
    ax.set_xlim(80, 332)
    # headroom top and bottom so no label presses a spine or the x-axis
    ax.set_ylim(33.5, 42.6)
    # the base dashed line is explained by a word label just outside the
    # right spine; the legend box stays three rows and off the data
    ax.text(1.015, avg_at_n("base"), "base model",
            transform=ax.get_yaxis_transform(), ha="left", va="center",
            fontsize=7.5, color=C["base"], clip_on=False)
    ax.set_xlabel(r"cumulative LR dose $B=\int \eta\,dt$ (peak lr $\times$ steps)")
    ax.set_ylabel("Avg@12 (mean of 3 bench.)")
    ax.set_title("Terminal performance vs. cumulative LR dose (1.7B)")
    ax.legend(frameon=False, fontsize=7.5, loc="upper right")
    ax.grid(alpha=0.25)
    fig.savefig(os.path.join(HERE, "fig8_drift_budget.pdf"))
    plt.close(fig)

# ---------------------------------------------------------------- Fig 9: loss drift
def fig9():
    """Clipped-loss trajectory, constant LR vs cosine decay (1.7B), with
    benchmark score below. Loss series parsed from ../data/logs/*.log."""
    def losses(fn):
        vals = []
        for line in open(os.path.join(LOGS, fn), errors="replace"):
            m = re.search(r"'loss': ([-0-9.e]+)", line)
            if m:
                vals.append(float(m.group(1)))
        v = np.array(vals)
        k = np.ones(5) / 5
        # edge-padded: mode="same" pulls the last two points toward zero
        return 2 * np.arange(1, len(v) + 1), np.convolve(np.pad(v, 2, mode="edge"), k, mode="valid")
    sc, lc = losses("opsd_baseline_long.log")
    sd, ld = losses("opsd_lrdecay.log")
    fig, (ax, ax2) = plt.subplots(2, 1, figsize=(5.6, 3.7), sharex=True,
                                  gridspec_kw={"height_ratios": [1.3, 1]})
    ax.plot(sc, lc, lw=1.3, color=C["baseline"], label="constant LR")
    ax.plot(sd, ld, lw=1.3, color=C["lrdecay"], label="cosine decay")
    ax.axhline(0, color="0.3", ls=":", lw=0.9)
    ax.axvline(100, color="0.85", lw=1, zorder=0)
    # terminal levels sit in a right margin beyond the last data point
    # (xlim 352 like fig12: the labels are ~40 steps wide, so 335 let
    # them press into the curve tails)
    ax.annotate(r"$-0.048$", (349, lc[-1]), ha="right", va="center",
                fontsize=7.5, color=C["baseline"])
    ax.annotate(r"$-0.026$", (349, ld[-1]), ha="right", va="center",
                fontsize=7.5, color=C["lrdecay"])
    ax.set_ylabel("clipped OPSD loss")
    ax.grid(alpha=0.25)
    # panel b: benchmark trajectory
    steps_b = [25, 50, 75, 100, 200, 300]
    vals_b = [avg_at_n(t) for t in ["baseline25", "baseline50", "baseline75",
                                    "baseline100", "baseline_long_200", "baseline_long_300"]]
    ax2.plot(steps_b, vals_b, marker="o", ms=3.5, lw=1.3, color=C["baseline"])
    steps_d = [200, 300]
    vals_d = [avg_at_n("lrdecay_200"), avg_at_n("lrdecay_300")]
    ax2.plot(steps_d, vals_d, marker="s", ms=3.5, lw=1.3, color=C["lrdecay"])
    ax2.axhline(avg_at_n("base"), color=C["base"], ls="--", lw=1.1)
    ax2.axvline(100, color="0.85", lw=1, zorder=0)
    ax2.text(102, ax2.get_ylim()[0] + 0.3, "original 100-step budget",
             fontsize=6.5, color="0.45")
    ax2.set_xlabel("training step")
    ax2.set_ylabel("Avg@12")
    ax2.set_xlim(0, 352)
    ax2.grid(alpha=0.25)
    # one shared legend above the top panel: the same colors mean the same
    # runs in both panels, so a single horizontal row labels both
    leg = ax.legend([Line2D([], [], lw=1.3, color=C["baseline"]),
                     Line2D([], [], lw=1.3, color=C["lrdecay"]),
                     Line2D([], [], lw=1.1, ls="--", color=C["base"])],
                    ["constant LR", "cosine decay", "base model"],
                    frameon=False, fontsize=7.5, ncol=3, loc="lower left",
                    bbox_to_anchor=(0.0, 1.02), handlelength=1.6,
                    columnspacing=1.2, handletextpad=0.5)
    fig.align_ylabels((ax, ax2))
    fig.savefig(os.path.join(HERE, "fig9_loss_drift.pdf"))
    plt.close(fig)

# ---------------------------------------------------------------- Fig 10: ablation deltas (horizontal bars)
def fig10():
    """Component ablations at step 100 (1.7B, seed 42): delta vs. family default.
    Horizontal bars, two panels (DAW components | hybrid hardening)."""
    daw_ref = avg_at_n("bandpass100")   # 41.5
    hyb_ref = avg_at_n("hybridv2_100")  # 41.6
    daw = [("hard-gate", avg_at_n("hardgate100")),
           ("hard-emphasis", avg_at_n("hardemph100")),
           ("easy-gate", avg_at_n("easygate100")),
           (r"floor $\varepsilon{=}0.3$", avg_at_n("daweps03_100"))]
    # sort by delta magnitude (largest first)
    daw.sort(key=lambda kv: kv[1] - daw_ref)
    hyb = [(r"$\alpha{=}0.1$" + "\n(v1 unhardened)", avg_at_n("hybrid100")),
           (r"$\alpha{=}0.05$" + "\n(hardened)", avg_at_n("hybrida005_100"))]

    fig, (a, b) = plt.subplots(1, 2, figsize=(5.6, 2.2),
                               gridspec_kw={"width_ratios": [1.15, 1]})
    for ax, items, ref, color in ((a, daw, daw_ref, C["bandpass"]),
                                  (b, hyb, hyb_ref, C["hybridv2"])):
        deltas = [v - ref for _, v in items]
        ys = np.arange(len(items))
        ax.barh(ys, deltas, height=0.5, color=color, alpha=0.9)
        for y, d in zip(ys, deltas):
            ax.text(d - 0.06, y, f"{d:+.1f}", va="center", ha="right",
                    fontsize=7.5, color="0.15")
        ax.axvline(0, color="0.2", lw=1)
        ax.set_yticks(ys)
        ax.set_yticklabels([n for n, _ in items], fontsize=7.5)
        ax.set_xlim(min(deltas) * 1.3, 0.45)
        ax.grid(alpha=0.25, axis="x")
    a.set_xlabel(r"$\Delta$ Avg@12 vs. family default", fontsize=8)
    b.set_xlabel(r"$\Delta$ Avg@12 vs. family default", fontsize=8)
    a.set_title("(a) DAW components (band-pass 41.5)", fontsize=9)
    b.set_title("(b) Hybrid hardening (v2 41.6)", fontsize=9)
    v1d = avg_at_n("hybrid100") - hyb_ref
    b.text(v1d + 0.18, 0.36, r"$\|g\|{\sim}10^{14}$ at step 35",
           fontsize=7, ha="left", va="center", color="0.3")
    fig.tight_layout()
    fig.savefig(os.path.join(HERE, "fig10_ablation.pdf"))
    plt.close(fig)

# ---------------------------------------------------------------- Fig 11: hyperparameter sweeps (2x2 small multiples)
def fig11():
    """Step-100 (1.7B, seed 42) sensitivity along four knobs, one per panel.
    Log-x sweeps; dashed line = frozen-teacher baseline; open marker = default."""
    base = avg_at_n("baseline100")  # 41.0
    fig, axs = plt.subplots(2, 2, figsize=(5.2, 3.7))

    def panel(ax, pts, color, title, xlabel, default_idx=None, log=True,
              loffs=None):
        # loffs: per-point (dx, dy, ha, va) overrides for the value labels
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        ax.plot(xs, ys, "-o", color=color, lw=1.3, ms=4)
        if default_idx is not None:
            ax.plot(xs[default_idx], ys[default_idx], "o", mfc="none", mec="black",
                    ms=7, mew=1.1)
        for i, (x, y) in enumerate(pts):
            off = (loffs[i] if loffs and loffs[i] else None) or (0, 14, "center", "baseline")
            dx, dy, ha, va = off
            ax.annotate(f"{y:.1f}", (x, y), textcoords="offset points",
                        xytext=(dx, dy), ha=ha, va=va, fontsize=7)
        ax.axhline(base, color=C["base"], ls="--", lw=1.1)
        if log:
            ax.set_xscale("log")
            ax.minorticks_off()
        ax.set_title(title, fontsize=9)
        ax.set_xlabel(xlabel, fontsize=8)
        ax.grid(alpha=0.25)

    # (a) clip threshold lambda: the curve runs 41.1 -> 41.0 -> 35.8 (drop at
    # the right); labels sit above the two plateau points, below the plunge
    # terminal; offsets are in points, i.e. x2.08 px at dpi 150
    panel(axs[0, 0],
          [(0.03, avg_at_n("clip03_100")), (0.05, base), (0.10, avg_at_n("clip10_100"))],
          C["baseline"], "(a) clip threshold", r"clip $\lambda$", default_idx=1,
          loffs=[(0, 8, "center", "baseline"), (0, 9, "center", "baseline"),
                 (-2, -9, "right", "top")])
    axs[0, 0].set_ylim(33.4, 43.4)
    axs[0, 0].set_xlim(0.027, 0.11)
    axs[0, 0].set_xticks([0.03, 0.05, 0.10])
    axs[0, 0].set_xticklabels(["0.03", "0.05", "0.10"], fontsize=7.5)
    # (b) hybrid coefficient alpha (0.1 = unhardened v1): plateau labels
    # above their points, terminal value above-right (below is the v1 note)
    panel(axs[0, 1],
          [(0.02, avg_at_n("hybridv2_100")), (0.05, avg_at_n("hybrida005_100")),
           (0.10, avg_at_n("hybrid100"))],
          C["hybridv2"], "(b) hybrid coefficient", r"coefficient $\alpha$", default_idx=0,
          loffs=[(0, 10, "center", "baseline"), (0, 9, "center", "baseline"),
                 (5, 7, "left", "baseline")])
    axs[0, 1].set_xticks([0.02, 0.05, 0.10])
    axs[0, 1].set_xticklabels(["0.02", "0.05", "0.10"], fontsize=7.5)
    # headroom top and bottom so no label, note, or word label presses a
    # spine; the dashed baseline carries the same word label as (a)
    axs[0, 1].set_xlim(0.0168, 0.137)
    axs[0, 1].set_ylim(33.4, 44.6)
    axs[0, 1].text(0.0205, base - 1.0, "frozen baseline 41.0", fontsize=6.5,
                   color=C["base"], ha="left", va="top")
    axs[0, 1].annotate("unhardened v1: " + r"$\|g\|{\sim}10^{14}$",
                       (0.10, avg_at_n("hybrid100")), textcoords="offset points",
                       xytext=(-2, -7), ha="right", va="top", fontsize=6.5,
                       color="0.3")
    # (c) EMA teacher decay, x = mobility (1 - decay): V shape 39.5 -> 39.4
    # -> 42.6; the V-bottom label goes below its point, "frozen limit" sits
    # as one line above the dashed line at the far left
    ax = axs[1, 0]
    ema = [(0.0005, avg_at_n("ema09995_100")), (0.001, avg_at_n("emateacher100")),
           (0.01, avg_at_n("ema0099_100"))]
    panel(ax, ema, C["refresh"], "(c) EMA teacher decay", r"mobility $1-\mathrm{decay}$",
          loffs=[(0, 10, "center", "baseline"), (-2, -8, "right", "top"),
                 (0, 10, "center", "baseline")])
    ax.set_xlim(0.00036, 0.0125)
    ax.set_ylim(38.0, 44.0)
    ax.set_xticks([0.0005, 0.001, 0.01])
    ax.set_xticklabels(["0.9995", "0.999", "0.99"], fontsize=7.5)
    ax.text(0.0005, base + 0.3, "frozen limit", fontsize=6.5, color="0.45",
            ha="left", va="bottom")
    # (d) DAW floor epsilon: headroom above and below so the dashed baseline
    # leaves the bottom spine and carries its word label like the others
    panel(axs[1, 1],
          [(0.1, avg_at_n("bandpass100")), (0.3, avg_at_n("daweps03_100"))],
          C["bandpass"], "(d) DAW floor", r"floor weight $\varepsilon$", default_idx=0,
          loffs=[(0, 18, "center", "baseline"), (-2, -14, "right", "top")])
    axs[1, 1].set_xlim(0.092, 0.32)
    axs[1, 1].set_ylim(39.6, 43.0)
    axs[1, 1].set_xticks([0.1, 0.3])
    axs[1, 1].set_xticklabels(["0.1", "0.3"], fontsize=7.5)
    axs[1, 1].text(0.105, base - 0.5, "frozen baseline 41.0", fontsize=6.5,
                   color=C["base"], ha="left", va="top")

    for ax in (axs[0, 0], axs[1, 0]):
        ax.set_ylabel("Avg@12, step-100", fontsize=8)
    axs[0, 0].text(0.0285, base - 1.0, "frozen baseline 41.0", fontsize=6.5,
                   color=C["base"], ha="left", va="top")
    fig.tight_layout()
    fig.savefig(os.path.join(HERE, "fig11_hyperparam.pdf"))
    plt.close(fig)

# ------------------------------------------------- Fig 12: loss trajectories
def fig12():
    """Training-loss trajectories: (a) constant vs. cosine for all three
    seeds, (b) schedule/anchor variants (seed 42).  Loss series parsed from
    ../data/logs/*.log; terminal levels quoted as means of the last five
    logged values (display curves 5-pt smoothed as in fig9)."""
    def raw(fn):
        vals = []
        for line in open(os.path.join(LOGS, fn), errors="replace"):
            m = re.search(r"'loss': ([-0-9.e]+)", line)
            if m:
                vals.append(float(m.group(1)))
        return np.array(vals)

    def smooth(v):
        # edge-padded 5-pt mean: unlike mode="same" this does not pull the
        # last two points toward zero, so terminal levels render faithfully
        return np.convolve(np.pad(v, 2, mode="edge"), np.ones(5) / 5, mode="valid")

    def steps_of(v):
        return 2 * np.arange(1, len(v) + 1)

    term = lambda v: float(np.mean(v[-5:]))  # quoted terminal level

    # wide-aspect source (5.6 x 4.6): rendered at 0.95\linewidth the figure
    # is ~27% wider than the old 4.6-wide source at 0.75\linewidth while
    # staying the same rendered height, so the enlargement does not add a
    # page in the appendix
    fig, (ax, ax2) = plt.subplots(2, 1, figsize=(5.6, 4.6), sharex=True,
                                  gridspec_kw={"height_ratios": [1, 1]})
    # ---- (a) three seeds, constant vs cosine
    runs_a = [  # (file, color, is_primary_seed)
        ("opsd_baseline_long.log",  C["baseline"], True),
        ("opsd_baseline_300_s1.log", C["baseline"], False),
        ("opsd_baseline_300_s2.log", C["baseline"], False),
        ("opsd_lrdecay.log",         C["lrdecay"],  True),
        ("opsd_lrdecay_300_s1.log",  C["lrdecay"],  False),
        ("opsd_lrdecay_300_s2.log",  C["lrdecay"],  False),
    ]
    term_a = {}
    for fn, col, primary in runs_a:
        v = raw(fn)
        st, sm = steps_of(v), smooth(v)
        ax.plot(st, sm, lw=1.4 if primary else 0.8, color=col,
                alpha=1.0 if primary else 0.45, zorder=3 if primary else 2)
        term_a[fn] = term(v)
    ax.axhline(0, color="0.3", ls=":", lw=0.9)
    # free space: every curve is negative past step 20, so the upper band
    # right of the legend hosts the note, and the terminal levels sit in a
    # right margin beyond the last data point
    ax.text(240, 0.0305, "zero crossed by step 20\nin all six runs",
            fontsize=6.5, color="0.45", ha="left", va="top")
    for fn, lab, col in [
            ("opsd_baseline_long.log", r"$-0.047$", C["baseline"]),
            ("opsd_lrdecay.log", r"$-0.026$", C["lrdecay"])]:
        ax.annotate(lab, (346, term_a[fn]), ha="right", va="center",
                    fontsize=7.5, color=col)
    ax.plot([], [], lw=1.4, color=C["baseline"], label="constant LR (seeds 42/1/2)")
    ax.plot([], [], lw=1.4, color=C["lrdecay"], label="cosine decay (seeds 42/1/2)")
    ax.legend(frameon=False, fontsize=7.5, loc="upper left",
              bbox_to_anchor=(0.07, 1.0))
    ax.set_ylabel("clipped OPSD loss")
    ax.set_title("(a) three seeds: constant vs. annealed", fontsize=8.5)
    ax.set_ylim(-0.056, 0.035)
    ax.grid(alpha=0.25)
    # ---- (b) variants, seed 42
    runs_b = [
        ("opsd_ema0099_300.log",    "EMA-0.99 teacher",   "#DD8452", "-",  1.3),
        ("opsd_baseline_long.log",  "const. $5{\\times}10^{-6}$", C["baseline"], "-", 1.3),
        ("opsd_symclip_300.log",    "symmetric clip",     "0.35",   "-",  1.1),
        ("opsd_lrdecay.log",        "cosine-300",         C["lrdecay"], "-", 1.3),
        ("opsd_const2p5e6_300.log", "const. $2.5{\\times}10^{-6}$", C["baseline"], "--", 1.1),
        ("opsd_dawdecay_300.log",   "DAW + cosine",       C["bandpass"], "-", 1.1),
        ("opsd_refresh200_300.log", "refresh-200",        C["refresh"], "-", 1.1),
    ]
    for fn, lab, col, ls, lw in runs_b:
        v = raw(fn)
        ax2.plot(steps_of(v), smooth(v), lw=lw, color=col, ls=ls, label=lab)
    ax2.axhline(0, color="0.3", ls=":", lw=0.9)
    # refresh reset: loss jumps at the step-200 merge; note sits in the
    # empty upper-right band, clear of the legend's second column, and
    # the arrow drops to the jump without crossing a curve
    ax2.annotate("objective resets\nat teacher refresh",
                 xy=(202, 0.0021), xytext=(255, 0.030), fontsize=6.5, color="0.35",
                 ha="left", va="top",
                 arrowprops=dict(arrowstyle="->", lw=0.7, color="0.45"))
    ax2.set_ylabel("clipped OPSD loss")
    ax2.set_xlabel("training step")
    ax2.set_title("(b) schedule and anchor variants (seed 42)", fontsize=8.5)
    # curves run to step 304; the margin beyond 346 keeps the terminal
    # labels in panel (a) clear of every tail
    ax2.set_xlim(0, 348)
    ax2.set_ylim(-0.056, 0.035)
    # column-major fill with ncol=2: a blank 4th slot balances the columns
    # and moving cosine-300 to the column-2 bottom row keeps it off the
    # curves that pass under the bottom of column 1
    hs, labs = ax2.get_legend_handles_labels()
    blank = Line2D([], [], linestyle="none")
    ax2.legend(hs[:3] + [blank] + hs[4:] + hs[3:4],
               labs[:3] + [""] + labs[4:] + labs[3:4],
               frameon=False, fontsize=6.5, ncol=2, loc="upper left",
               bbox_to_anchor=(0.055, 1.0), handlelength=1.6,
               columnspacing=1.0, handletextpad=0.5)
    ax2.grid(alpha=0.25)
    fig.align_ylabels((ax, ax2))
    fig.savefig(os.path.join(HERE, "fig12_loss_convergence.pdf"))
    fig.savefig(os.path.join(HERE, "fig12_loss_convergence.png"), dpi=200)
    plt.close(fig)
    # print quoted terminal levels for the paper text
    print("fig12 terminal five-step means:")
    for fn, lab, *_ in runs_b:
        print(f"  {lab:26s} {term(raw(fn)):+.4f}")
    for fn, _, _ in runs_a:
        print(f"  {os.path.basename(fn):26s} {term(raw(fn)):+.4f}")

if __name__ == "__main__":
    dump_table_json()
    for fn in (fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8, fig9, fig10, fig11, fig12):
        fn()
        print("built", fn.__name__)
