import json, glob, os

import sys
RAW = sys.argv[1] if len(sys.argv) > 1 else os.environ.get("OPSD_EVAL_DIR", "eval_results")
OUT = sys.argv[2] if len(sys.argv) > 2 else "compact_results.json"
res = {}
for f in sorted(glob.glob(os.path.join(RAW, "*.json"))):
    tag = os.path.basename(f).replace(".json", "")
    d = json.load(open(f))
    entry = {
        "dataset": d.get("dataset"),
        "val_n": d.get("val_n"),
        "num_problems": d.get("num_problems"),
        "avg_at_n_pct": d.get("average_at_n_pct"),
        "pass_at_n_pct": d.get("pass_at_n_pct"),
        "maj_at_n_pct": d.get("majority_vote_at_n_pct"),
        "avg_len": None,
    }
    # mean generation length (for length-inflation analysis)
    gens = []
    for r in d.get("results", []):
        g = r.get("full_generation") or ""
        if isinstance(g, list):
            gens.extend(len(x) for x in g)
        elif g:
            gens.append(len(g))
    if gens:
        entry["avg_len"] = sum(gens) / len(gens)
    res[tag] = entry

# failure-gallery samples: a few generations from the teacher-refresh eval
gallery = {}
for tag in ["teacherrefreshv2_300_aime24"]:
    f = os.path.join(RAW, f"{tag}.json")
    if os.path.exists(f):
        d = json.load(open(f))
        samples = []
        for r in d.get("results", [])[:3]:
            g = r.get("full_generation") or ""
            if isinstance(g, list):
                g = g[0] if g else ""
            samples.append({"problem": (r.get("problem") or "")[:300], "generation": g[:1200]})
        gallery[tag] = samples

json.dump({"results": res, "gallery": gallery}, open(OUT, "w"), indent=1)
print("compact entries:", len(res), "| size:", os.path.getsize(OUT))
