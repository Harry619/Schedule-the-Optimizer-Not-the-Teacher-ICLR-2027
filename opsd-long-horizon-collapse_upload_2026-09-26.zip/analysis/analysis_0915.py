#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""2026-09-15 canonical analysis run (single source of truth for ALL paper CIs).

Protocol (unchanged from the 9/11 canonical discipline; draw sequence is new
because the script was rewritten, so EVERY CI in the paper is refreshed from
this single run):
  - paired bootstrap over the 90 competition problems (aime24+aime25+hmmt25),
    aligned problem-by-problem (problem_id), 10,000 resamples,
    numpy default_rng(2026), percentile 95% CIs.
Also: appends the post-9/9 experiment records to compact_results.json
(append-only; existing keys never modified) and verifies point estimates
against the previously published values.

Usage:  python analysis_0915.py
"""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, 'eval_results_daw')
BENCH = ['aime24', 'aime25', 'hmmt25']

# ---------------------------------------------------------------- compact append
COMPACT_PATH = os.path.join(HERE, 'compact_results.json')
compact = json.load(open(COMPACT_PATH, encoding='utf-8'))
res = compact['results']

NEW_TAGS = ['const2p5e6_300', 'ema0099_100', 'ema09995_100', 'ema0099_300',
            'dawdecay_300', 'dawdecay_300_s1', 'dawdecay_300_s2',
            'symclip_300', 'symclip_300_s1', 'symclip_300_s2', 'fp32_300',
            'matched100', 'matched300', 'refresh200_200', 'refresh200_300',
            'decay100', 'lrdecay_300_s1', 'lrdecay_300_s2',
            'baseline_300_s1', 'baseline_300_s2']

added = 0
for tag in NEW_TAGS:
    for b in BENCH:
        key = f'{tag}_{b}'
        if key in res:
            continue
        p = os.path.join(RAW, key + '.json')
        if not os.path.exists(p):
            print(f'  [compact] SKIP missing raw: {key}')
            continue
        j = json.load(open(p, encoding='utf-8'))
        lens = []
        for it in j['results']:
            for g in it.get('generations', []):
                fg = g.get('full_generation')
                if fg:
                    lens.append(len(fg))
        rec = {'dataset': b, 'val_n': j['results'][0]['val_n'],
               'num_problems': len(j['results']),
               'avg_at_n_pct': j['average_at_n_pct'],
               'pass_at_n_pct': j['pass_at_n_pct'],
               'maj_at_n_pct': j['majority_vote_at_n_pct'],
               'avg_len': (sum(lens) / len(lens)) if lens else None}
        res[key] = rec
        added += 1
res_sorted = {k: res[k] for k in sorted(res)}
compact['results'] = res_sorted
compact.setdefault('_meta', {})['appended_2026_09_15'] = (
    f'{added} records appended (append-only) from eval_results_daw raw JSONs')
json.dump(compact, open(COMPACT_PATH, 'w', encoding='utf-8'),
          ensure_ascii=False, indent=1)
print(f'[compact] appended {added} records (total {len(res_sorted)}); '
      'existing keys untouched' if added else '[compact] nothing to append')

# ---------------------------------------------------------------- helpers
def per_problem(tag):
    """{problem_id: accuracy in [0,1]} pooled over the three benchmarks."""
    out = {}
    for b in BENCH:
        j = json.load(open(os.path.join(RAW, f'{tag}_{b}.json'), encoding='utf-8'))
        for it in j['results']:
            pid = f'{b}:{it["problem_id"]}'
            assert pid not in out
            out[pid] = it['num_correct'] / it['val_n']
    assert len(out) == 90, (tag, len(out))
    return out

CACHE = {}
def get(tag):
    if tag not in CACHE:
        CACHE[tag] = per_problem(tag)
    return CACHE[tag]

import numpy as np

def paired_boot(tagA, tagB, n_boot=10_000, rng=None):
    a, b = get(tagA), get(tagB)
    pids = sorted(a)
    da = np.array([a[p] for p in pids])
    db = np.array([b[p] for p in pids])
    n = len(pids)
    point = float((da.mean() - db.mean()) * 100)
    if rng is None:
        return point, None, None
    idx = rng.integers(0, n, size=(n_boot, n))
    diffs = (da[idx].mean(axis=1) - db[idx].mean(axis=1)) * 100
    lo, hi = np.percentile(diffs, [2.5, 97.5])
    return point, float(lo), float(hi)

# ------------------------------------------------- canonical pair list (fixed)
PAIRS = [
    # (label, scale, tagA, tagB, published_point_for_verification)
    ('const vs base',        '1.7B', 'baseline_long_300',  'base',               -3.0),
    ('const vs peak(75)',    '1.7B', 'baseline_long_300',  'baseline75',         -7.4),
    ('decay vs const',       '1.7B', 'lrdecay_300',        'baseline_long_300',  +4.2),
    ('decay vs base',        '1.7B', 'lrdecay_300',        'base',               +1.2),
    ('linear vs cosine',     '1.7B', 'lineardecay_300',    'lrdecay_300',        -0.1),
    ('DAW vs const',         '1.7B', 'bandpass_long_300',  'baseline_long_300',  -0.6),
    ('hybrid vs const',      '1.7B', 'hybridv2_long_300',  'baseline_long_300',  -1.7),
    ('refresh vs const',     '1.7B', 'teacherrefreshv2_300','baseline_long_300', -29.4),
    ('const-1/2LR vs decay', '1.7B', 'const2p5e6_300',     'lrdecay_300',        None),   # new
    ('DAW+decay vs decay',   '1.7B', 'dawdecay_300',       'lrdecay_300',        None),   # new
    ('symclip vs const',     '1.7B', 'symclip_300',        'baseline_long_300',  None),   # new
    ('EMA0.99 vs const',     '1.7B', 'ema0099_300',        'baseline_long_300',  None),   # new
    ('refresh200 vs const',  '1.7B', 'refresh200_300',     'baseline_long_300',  None),   # new
    ('fp32 vs const',        '1.7B', 'fp32_300',           'baseline_long_300',  None),   # new
    ('const vs base',        '4B',   '4b_baseline_long_300','4b_base',           -9.1),
    ('decay vs const',       '4B',   '4b_lrdecay_long_300','4b_baseline_long_300', +5.3),
    ('decay vs base',        '4B',   '4b_lrdecay_long_300','4b_base',            -3.8),
    ('refresh vs const',     '4B',   '4b_teacherrefresh_300','4b_baseline_long_300', -47.8),
    ('const vs base',        '8B',   '8b_baseline_long_300','8b_base',           -5.4),
    ('decay vs const',       '8B',   '8b_lrdecay_300',     '8b_baseline_long_300', +5.3),
    ('decay vs base',        '8B',   '8b_lrdecay_300',     '8b_base',            -0.1),
    ('DAW vs const',         '8B',   '8b_bandpass_long_300','8b_baseline_long_300', -0.8),
]

rng = np.random.default_rng(2026)
out_rows = []
print(f'\n{"pair":24s} {"scale":5s} {"delta":>7s}  {"95% CI":>18s}  verify')
for label, scale, ta, tb, pub in PAIRS:
    point, lo, hi = paired_boot(ta, tb, rng=rng)
    ok = ''
    if pub is not None:
        ok = 'OK' if abs(point - pub) < 0.055 else f'MISMATCH pub={pub}'
    print(f'{label:24s} {scale:5s} {point:+7.2f}  [{lo:+6.2f}, {hi:+6.2f}]  {ok}')
    out_rows.append({'pair': label, 'scale': scale, 'A': ta, 'B': tb,
                     'delta': round(point, 2), 'lo': round(lo, 2), 'hi': round(hi, 2),
                     'published_point': pub})

with open(os.path.join(HERE, 'bootstrap_canonical_0915.json'), 'w', encoding='utf-8') as fh:
    json.dump({'protocol': 'paired problem bootstrap, 90 problems, 10000 draws, '
                           'default_rng(2026), percentile CI',
               'pairs': out_rows}, fh, ensure_ascii=False, indent=1)
print('\nwritten: data/bootstrap_canonical_0915.json')
