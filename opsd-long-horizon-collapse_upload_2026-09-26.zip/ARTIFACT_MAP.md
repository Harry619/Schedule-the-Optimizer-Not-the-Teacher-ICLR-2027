# Artifact Map

Maps every table, figure, and quantitative claim in the paper
(*Schedule the Optimizer, Not the Teacher: Diagnosing and Mitigating
Long-Horizon Collapse in On-Policy Self-Distillation*) to the artifacts in
this repository, and records the consistency audit performed on 2026-09-26.

## 1. Mirrored availability statement (paper Appendix D)

> The anonymous repository contains the complete artifact set behind the
> paper. It is a fork of the official OPSD code (commit `7448751`) whose
> default code path is unmodified; every extension used in the paper is
> gated behind a flag that is default-off. The set contains the extended
> training code with all switches, the evaluation pipeline, per-problem
> correctness for all 128 evaluation files (`per_problem_scores.json`), and
> the append-only results ledger with 313 records (`compact_results.json`),
> to which every number in the paper traces. It further contains the
> canonical bootstrap script, which regenerates every interval in the CI
> table bit-for-bit under its fixed seed, the figure-generation script, the
> 20 training logs behind the loss and divergence figures, and CPU-runnable
> unit tests for the reward parsing and the refresh checkpointing. A
> `REPRODUCING.md` file maps each paper claim to the exact command that
> produces it, mirroring the run registry appendix, and the pinned
> environment file matches the paper's environment table entry for entry.

## 2. Paper item → repository artifact

| Paper item | Artifact | How to regenerate / verify |
|---|---|---|
| Headline results (mean of 3 benchmarks, all variants, all steps) | `analysis/compact_results.json` (313 records; per-record `dataset`, `avg_at_n_pct`, `pass_at_n_pct`, `maj_at_n_pct`, `avg_len`) | means recomputed from the per-benchmark records |
| All confidence intervals (paper CI table, 24 rows) | `analysis/bootstrap_canonical.py` → `bootstrap_canonical_0915.json` | `cd analysis && python bootstrap_canonical.py` (fixed seed `default_rng(2026)`, 10,000 problem resamples; output matches the shipped JSON exactly) |
| Collapse / mechanism / dose / EMA / multi-seed / 4B / grad-explosion / DAW-dynamics / loss figures (paper figs. 1–12) | `analysis/gen_figures.py` (functions `fig1`–`fig12`) | `cd analysis && python gen_figures.py` |
| Per-problem analysis figure | `analysis/per_problem_scores.json` (128 evaluation files) | data are per-problem, per-sample counts |
| Per-benchmark trajectory figure | `analysis/compact_results.json` (`dataset` field) | per-benchmark records exist for every run |
| Response-length statistics figure | `analysis/compact_results.json` (`avg_len` field) | `avg_len` recorded per evaluation |
| Format-rate table (evaluation-artifact check) | `analysis/format_rate_table.py` | `cd analysis && python format_rate_table.py` |
| Unclipped-divergence trajectory | `analysis/e6_divergence_full300.json` | shipped |
| Run registry (every run → config delta → evaluated checkpoints) | `REPRODUCING.md` + `scripts/train/` | one launch script per family; `REPRODUCING.md` maps claim → command |
| Trainer switches (DAW, RLVR hybrid, teacher refresh, EMA, symmetric clip, fp32) | `opsd_train.py` / `opsd_trainer.py` | all flags present and default-off |
| Environment pins | `environment.yml` / `requirements.txt` | matches the paper environment table entry for entry |
| Unit tests | `scripts/tests/smoke_reward.py`, `scripts/tests/test_refresh_save.py` | CPU-runnable |
| Server-side compute estimate | `analysis/estimate_compute.py` | `cd analysis && python estimate_compute.py` |

## 3. Compute calibers

`estimate_compute.py` recomputes the server-side total from the shipped
ledger: about 1,343 A800 GPU-hours (68 run families, 297 competition
evaluations, 16 MATH500 evaluations). The paper's compute appendix reports
about 1,850 GPU-hours (88 runs, 451 evaluations); that fuller ledger
additionally counts external-machine replications, which the paper prices by
same-type A800 anchors and discloses as analog-estimated. The two numbers
differ in scope, not in error: the repository script covers what the shipped
artifacts alone can recompute.

## 4. Consistency audit record (2026-09-26)

Checklist performed against the submission PDF:

| # | Check | Result |
|---|---|---|
| 1 | All configuration switches used in the paper exist and are default-off (`difficulty_aware`, `daw_eps`, `hybrid_alpha`, `teacher_refresh_every`, `use_ema_teacher`/`ema_decay`, `jsd_symmetric_clip`, `kl_fp32`) | pass |
| 2 | Every run family in the paper's registry maps to a launch script and ledger tags (`REPRODUCING.md`) | pass |
| 3 | Bootstrap script regenerates the CI table exactly | pass after fix: the two clip-removed rows were appended to `PAIRS` (end of list, same protocol and RNG stream); all 24 rows now regenerate, the original 22 unchanged bit-for-bit |
| 4 | Ledger covers the paper's numbers (spot-verified: 35.1 / 39.3 / 5.7 / 32.5 / 38.8 / 39.2 / 35.7 / 35.4 / 4B seeds 56.9, 57.9, 58.1 / 3.9 / 1.4 / 64.1 / 58.0 / 33.4 / 41.0) | pass |
| 5 | `environment.yml` = paper environment table (torch 2.8.0, transformers 4.57.1, trl 0.26.0, accelerate 1.11.0, peft 0.17.1, deepspeed 0.18.2, vllm 0.11.0, datasets 3.6.0, flash-attn 2.8.3, math-verify 0.8.0) | pass |
| 6 | Compute disclosures consistent (two calibers, Section 3 above) | pass |
| 7 | Generative-AI statement consistent with repository state | pass |

Corrections applied during the audit: README record count 280 → 313 (twice);
README CI count 22 → 24; README summary point 3 rewritten to match the
paper's falsification of the EMA teacher (it matches the best early score
but ends below the frozen teacher's endpoint at every rate); REPRODUCING.md
secondary-studies section pointer corrected to Section 7; the two
clip-removed pairs added to the canonical bootstrap pair list (see check 3).
