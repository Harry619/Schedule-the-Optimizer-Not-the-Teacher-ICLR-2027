# Reproducing the paper

Claim-by-claim mapping from the paper to commands and data. All scripts are
idempotent (existing checkpoints/results are skipped). Tags below are the
directory/result names used in `analysis/compact_results.json`.

Conventions:
- `GPUS` is a CUDA id list, e.g. `0,1,2,3`.
- The paper protocol for competition benchmarks is Avg@12 at temperature 1.0,
  thinking mode, `max_new_tokens=38912` — this is exactly what
  `scripts/eval/eval_ckpt.sh` runs.
- Training runs use the official hyperparameters (lr 5e-6, global batch 32,
  completion 1024, clip 0.05, temp 1.1, LoRA r=64/α=128) unless a flag below
  says otherwise.

## 1. Official-protocol reproduction (100 steps)

| Paper item | Command |
|---|---|
| 1.7B baseline, step-100 peak | `bash scripts/train/run_opsd_1b.sh` (stop after checkpoint-100), then `bash scripts/eval/eval_ckpt.sh <out>/checkpoint-100 baseline100 0,1,2,3` |
| Base-model scores | `bash scripts/eval/eval_base.sh` (`_4b`, `_8b` for other scales) |
| MATH500 | `bash scripts/eval/eval_math500*.sh` |

## 2. Long-horizon collapse (Section 4)

| Run | Command |
|---|---|
| 1.7B constant-LR 300 steps | `bash scripts/train/long_run_300.sh baseline_long 0,1,2,3 none` |
| 1.7B cosine decay → 0 over 300 | `bash scripts/train/long_run_300.sh lrdecay 0,1,2,3 none --lr_scheduler_type cosine --max_steps 300` |
| 4B / 8B variants | `scripts/train/long_run_300_4b.sh`, `long_run_300_8b.sh` |
| 500-step decay horizon | `scripts/train/long_run_500.sh` |
| Linear decay / half-LR controls | `long_run_300.sh <tag> ... --lr_scheduler_type linear --max_steps 300` / `--learning_rate 2.5e-6` |

## 3. Mechanism discrimination (Section 5–6)

| Run | Command |
|---|---|
| Teacher refresh every 100 steps | `scripts/train/teacherrefresh_v2.sh` (`_4b` for 4B) |
| Refresh + decay combination | `scripts/train/refresh_decay_combo.sh` (`_4b`) |
| EMA teacher (100-step scans) | `scripts/train/run_opsd_1b_ema.sh` |
| EMA teacher 300-step terminals | `scripts/train/run_ema300.sh <tag> <decay> <gpus>` |
| Symmetric clip probe | `long_run_300.sh symclip_300 ... --jsd_symmetric_clip` |
| fp32 divergence control | `long_run_300.sh fp32_300 ... --kl_fp32` |
| Divergence family (JSD β=0.5 / reverse KL β=1) | `scripts/train/long_run_300_beta.sh <tag> <gpus> none <beta>` (see `divq.sh`) |

## 4. Secondary studies (Section 8)

| Run | Command |
|---|---|
| DAW band-pass | `bash scripts/train/run_opsd_1b_daw.sh bandpass` |
| DAW + decay | `long_run_300.sh dawdecay_300 ... --difficulty_aware bandpass --lr_scheduler_type cosine --max_steps 300` |
| RLVR hybrid | add `--hybrid_alpha 0.02` to any training script |

## 5. Statistics, tables, and figures

| Artifact | Command |
|---|---|
| All 22 CIs (Table: CI) | `cd analysis && python bootstrap_canonical.py` → must match the shipped `bootstrap_canonical_0915.json` byte-for-byte in values |
| All matplotlib figures | `cd analysis && python gen_figures.py` |
| Result ledger | `analysis/compact_results.json` (280 records, append-only) |
| Per-problem scores | `analysis/per_problem_scores.json` (all 128 evaluation files) |
| Full 300-step divergence trajectory | `analysis/e6_divergence_full300.json` (parsed from the `bandpass_long` log) |

The raw per-problem evaluation JSONs (~3.5 GB, with full generations) are not
shipped. To regenerate them, run the evaluation scripts above; then
`python analysis/extract_per_problem.py <raw_dir> analysis/per_problem_scores.json`
reproduces the shipped compact file, and `python analysis/compact_results.py
<raw_dir>` regenerates ledger records. `analysis/analysis_0915.py` is the
original canonical script that runs against the raw files.

## Unit tests (CPU)

```bash
python scripts/tests/smoke_reward.py        # boxed extraction + reward judging
python scripts/tests/test_refresh_save.py   # teacher-refresh merged-save behavior
```
